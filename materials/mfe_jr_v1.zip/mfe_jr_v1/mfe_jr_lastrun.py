﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.5),
    on April 16, 2025, at 17:20
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard

# Run 'Before Experiment' code from arrow_stim_sizes
arrow_size = [0.48, 0.48]
instruct_center_arrow_location = (0, -3.2)
instruct_right1_arrow_location = (0.57, -3.2)
instruct_right2_arrow_location = (1.13, -3.2)
instruct_left1_arrow_location = (-0.57, -3.2)
instruct_left2_arrow_location = (-1.13, -3.2)
# Run 'Before Experiment' code from shuffling_surprise
import pandas as pd
import numpy as np
import glob
import os
import math # Needed for floor function if not using integer division
import pathlib

# =========================================================================
# Configuration
# =========================================================================

# get the current working directory
current_working_directory = os.getcwd()

# Directory containing the original 4 surprise block CSV files (output from MATLAB)
input_csv_directory = pathlib.Path(current_working_directory) 

# Directory where the NEW shuffled and BALANCED CSV files will be saved
output_csv_directory = pathlib.Path(current_working_directory)

# Filename pattern for the INPUT surprise blocks
input_file_pattern = 'surprise_block_*.csv' # Should match MATLAB script's cfg.outputPrefixSurprise

# Filename prefix for the OUTPUT shuffled and balanced surprise blocks
output_file_prefix = 'shuffled_surprise_block_' # Changed prefix to distinguish output

# Number of output surprise blocks to create
NUM_OUTPUT_BLOCKS = 4
# =========================================================================

print(f"--- Starting Python Script to Balance Foils Across Blocks ---")

# --- Validate and Prepare Directories ---
if not os.path.isdir(input_csv_directory):
    print(f"ERROR: Input directory not found: {input_csv_directory}")
    exit()

if not os.path.isdir(output_csv_directory):
    print(f"Output directory not found. Creating: {output_csv_directory}")
    try:
        os.makedirs(output_csv_directory)
    except OSError as e:
        print(f"ERROR: Could not create output directory: {output_csv_directory}")
        print(f"System Error: {e}")
        exit()
else:
    print(f"Output directory found: {output_csv_directory}")

# --- Find Input Files ---
search_pattern = os.path.join(input_csv_directory, input_file_pattern)
print(f"Looking for input files matching: {search_pattern}")
input_files = glob.glob(search_pattern)

if len(input_files) == 0:
    print(f"ERROR: No input files found matching the pattern.")
    exit()
# Note: We load all found files regardless of EXPECTED_INPUT_FILES now, as we combine them anyway.
print(f"Found {len(input_files)} input surprise block files.")

# --- Load and Concatenate CSV Files ---
print("Loading and combining input CSV files...")
list_of_dataframes = []
for f in input_files:
    try:
        df_temp = pd.read_csv(f)
        if 'surpriseFaces' in df_temp.columns and 'new' in df_temp.columns:
            # Ensure 'new' column is integer type
            df_temp['new'] = df_temp['new'].astype(int)
            list_of_dataframes.append(df_temp)
            print(f"  Loaded: {os.path.basename(f)} ({len(df_temp)} rows)")
        else:
            print(f"  WARNING: File {os.path.basename(f)} missing columns. Skipping.")
    except Exception as e:
        print(f"  ERROR: Could not read file {os.path.basename(f)}. Error: {e}. Skipping.")

if not list_of_dataframes:
    print("ERROR: No valid CSV files were loaded. Cannot proceed.")
    exit()

combined_df = pd.concat(list_of_dataframes, ignore_index=True)
total_rows = len(combined_df)
print(f"Successfully combined data into a single DataFrame with {total_rows} rows.")

# --- Separate Old and Foil (New) Items ---
print("Separating 'old' (new=0) and 'foil' (new=1) items...")
old_df = combined_df[combined_df['new'] == 0].copy()
foil_df = combined_df[combined_df['new'] == 1].copy()
num_old = len(old_df)
num_foils = len(foil_df)
print(f"  Found {num_old} 'old' items and {num_foils} 'foil' items.")

# --- Shuffle Old and Foil DataFrames Separately ---
print("Shuffling 'old' and 'foil' lists independently...")
if num_old > 0:
    shuffled_old_df = old_df.sample(frac=1).reset_index(drop=True)
else:
    shuffled_old_df = old_df # Keep empty if no old items
if num_foils > 0:
    shuffled_foil_df = foil_df.sample(frac=1).reset_index(drop=True)
else:
    shuffled_foil_df = foil_df # Keep empty if no foil items

# --- Calculate Distribution Across Output Blocks ---
print(f"Calculating distribution for {NUM_OUTPUT_BLOCKS} output blocks...")
# Calculate base number and remainder for OLD items
base_old_per_block = num_old // NUM_OUTPUT_BLOCKS
rem_old = num_old % NUM_OUTPUT_BLOCKS
print(f"  Old items per block: Base={base_old_per_block}, Remainder={rem_old}")
# Calculate base number and remainder for FOIL items
base_foils_per_block = num_foils // NUM_OUTPUT_BLOCKS
rem_foils = num_foils % NUM_OUTPUT_BLOCKS
print(f"  Foil items per block: Base={base_foils_per_block}, Remainder={rem_foils}")

# --- Create and Save Balanced Blocks ---
print(f"Creating {NUM_OUTPUT_BLOCKS} balanced blocks and saving...")
current_old_idx = 0
current_foil_idx = 0
output_blocks_list = [] # Store blocks before saving

for i in range(NUM_OUTPUT_BLOCKS):
    block_number = i + 1
    print(f"  Processing Block {block_number}...")

    # Determine number of old items for this block
    num_old_this_block = base_old_per_block + (1 if i < rem_old else 0)
    # Determine number of foil items for this block
    num_foils_this_block = base_foils_per_block + (1 if i < rem_foils else 0)

    # Define slice ranges
    start_old = current_old_idx
    end_old = current_old_idx + num_old_this_block
    start_foil = current_foil_idx
    end_foil = current_foil_idx + num_foils_this_block

    # Select portions using iloc for positional indexing on shuffled data
    old_portion = shuffled_old_df.iloc[start_old:end_old]
    foil_portion = shuffled_foil_df.iloc[start_foil:end_foil]

    # Update indices for next iteration
    current_old_idx = end_old
    current_foil_idx = end_foil

    # Combine the portions for this block
    block_df_combined = pd.concat([old_portion, foil_portion], ignore_index=True)

    # Shuffle rows WITHIN this combined block
    if not block_df_combined.empty:
        block_df_final = block_df_combined.sample(frac=1).reset_index(drop=True)
    else:
        block_df_final = block_df_combined # Keep empty if it started empty

    # --- Save the final block DataFrame ---
    output_filename = f"{output_file_prefix}{block_number}.csv"
    output_filepath = os.path.join(output_csv_directory, output_filename)

    if not block_df_final.empty:
        try:
            block_df_final.to_csv(output_filepath, index=False)
            print(f"    Saved {len(block_df_final)} total rows ({num_old_this_block} old, {num_foils_this_block} foil) to: {output_filename}")
        except Exception as e:
            print(f"    ERROR: Could not save file {output_filename}. Error: {e}")
    else:
        print(f"    Skipping saving for Block {block_number} as it is empty.")

print("--- Python Script to Balance Foils Finished ---")


# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.5'
expName = 'mfe_jr_v1'  # from the Builder filename that created this script
expInfo = {
    'id': '',
    'cb': ['A', 'B'],
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['id'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='E:\\mfe_jr_legion_ver\\mfe_jr_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.DEBUG)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1920, 1080], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='sys-1-asus-60cm', color='0.5000, 0.5000, 0.5000', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='deg')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "JS_code" ---

# --- Initialize components for Routine "setup" ---
# Run 'Begin Experiment' code from setup_code
import serial #used for sending eeg triggers
import time #indirerctly used for sending eeg triggers (how long to wait before clearing port)


win.mouseVisible = False #hide mouse cursor
port = serial.Serial('COM4') #open specified port (COM3) for sending eeg triggers to           
PulseWidth = 0.002 #how long to wait before clearing port after sending trigger (2 ms is sufficient at 1000 hz sampling rate)

port.write([0x00]) #clear serial port
time.sleep(PulseWidth) #wait PulseWidth amount of time before doing anything else

# --- Initialize components for Routine "welcome" ---
welcome_keyResp = keyboard.Keyboard()
welcome_keyResp2 = keyboard.Keyboard()
welcome_text1 = visual.TextStim(win=win, name='welcome_text1',
    text='',
    font='Arial',
    units='deg', pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
welcome_text2 = visual.TextStim(win=win, name='welcome_text2',
    text='',
    font='Arial',
    units='deg', pos=(0, 0), height=0.8, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# --- Initialize components for Routine "instructRightSingle" ---
instructRightSingle_keyResp = keyboard.Keyboard()
instructRightSingle_keyResp_2 = keyboard.Keyboard()
instructRightSingle_keyResp_3 = keyboard.Keyboard()
instructRightSingle_keyResp_4 = keyboard.Keyboard()
instructRightSingle_keyResp_5 = keyboard.Keyboard()
instructRightSingle_text = visual.TextStim(win=win, name='instructRightSingle_text',
    text='This arrow is pointing to the RIGHT. \n\n\n\n\n\n\n\n\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-5.0);
instructRightSingle_text_2 = visual.TextStim(win=win, name='instructRightSingle_text_2',
    text='This arrow is pointing to the RIGHT. \n\nYou can tell this arrow is pointing to the RIGHT by looking at which side the point is on.\n\n\n\n\n\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);
instructRightSingle_text_3 = visual.TextStim(win=win, name='instructRightSingle_text_3',
    text='This arrow is pointing to the RIGHT. \n\nYou can tell this arrow is pointing to the RIGHT by looking at which side the point is on.\n\nThe point is on the RIGHT, so the arrow is pointing this way.\n\n\n\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-7.0);
instructRightSingle_text_4 = visual.TextStim(win=win, name='instructRightSingle_text_4',
    text='This arrow is pointing to the RIGHT. \n\nYou can tell this arrow is pointing to the RIGHT by looking at which side the point is on.\n\nThe point is on the RIGHT, so the arrow is pointing this way.\n\nYou would respond to this arrow by pressing the RIGHT button with your RIGHT hand.\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-8.0);
instructRightSingle_text_5 = visual.TextStim(win=win, name='instructRightSingle_text_5',
    text='This arrow is pointing to the RIGHT. \n\nYou can tell this arrow is pointing to the RIGHT by looking at which side the point is on.\n\nThe point is on the RIGHT, so the arrow is pointing this way.\n\nYou would respond to this arrow by pressing the RIGHT button with your RIGHT hand.\n\nPress the RIGHT button to continue.\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-9.0);
instructRightSingle_rightArrow = visual.ImageStim(
    win=win,
    name='instructRightSingle_rightArrow', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=(0, -3.2), size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-10.0)
instructRightSingle_rightArrowHighlight = visual.ImageStim(
    win=win,
    name='instructRightSingle_rightArrowHighlight', 
    image='img/rightArrowHighlight.png', mask=None, anchor='center',
    ori=0, pos=(0, -3.2), size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-11.0)
instructRightSingle_rightArrowSolid = visual.ImageStim(
    win=win,
    name='instructRightSingle_rightArrowSolid', 
    image='img/rightArrowSolid.png', mask=None, anchor='center',
    ori=0, pos=(0, -3.8), size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-12.0)

# --- Initialize components for Routine "instructLeftSingle" ---
instructLeftSingle_keyResp = keyboard.Keyboard()
instructLeftSingle_keyResp_2 = keyboard.Keyboard()
instructLeftSingle_keyResp_3 = keyboard.Keyboard()
instructLeftSingle_keyResp_4 = keyboard.Keyboard()
instructLeftSingle_keyResp_5 = keyboard.Keyboard()
instructLeftSingle_text = visual.TextStim(win=win, name='instructLeftSingle_text',
    text='This arrow is pointing to the LEFT. \n\n\n\n\n\n\n\n\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-5.0);
instructLeftSingle_text_2 = visual.TextStim(win=win, name='instructLeftSingle_text_2',
    text='This arrow is pointing to the LEFT. \n\nYou can tell this arrow is pointing to the LEFT by looking at which side the point is on.\n\n\n\n\n\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-6.0);
instructLeftSingle_text_3 = visual.TextStim(win=win, name='instructLeftSingle_text_3',
    text='This arrow is pointing to the LEFT. \n\nYou can tell this arrow is pointing to the LEFT by looking at which side the point is on.\n\nThe point is on the LEFT, so the arrow is pointing this way.\n\n\n\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-7.0);
instructLeftSingle_text_4 = visual.TextStim(win=win, name='instructLeftSingle_text_4',
    text='This arrow is pointing to the LEFT. \n\nYou can tell this arrow is pointing to the LEFT by looking at which side the point is on.\n\nThe point is on the LEFT, so the arrow is pointing this way.\n\nYou would respond to this arrow by pressing the LEFT button with your LEFT hand.\n\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-8.0);
instructLeftSingle_text_5 = visual.TextStim(win=win, name='instructLeftSingle_text_5',
    text='This arrow is pointing to the LEFT. \n\nYou can tell this arrow is pointing to the LEFT by looking at which side the point is on.\n\nThe point is on the LEFT, so the arrow is pointing this way.\n\nYou would respond to this arrow by pressing the LEFT button with your LEFT hand.\n\nPress the LEFT button to continue.\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-9.0);
instructLeftSingle_leftArrow = visual.ImageStim(
    win=win,
    name='instructLeftSingle_leftArrow', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=(0, -3.2), size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-10.0)
instructLeftSingle_leftArrowHighlight = visual.ImageStim(
    win=win,
    name='instructLeftSingle_leftArrowHighlight', 
    image='img/leftArrowHighlight.png', mask=None, anchor='center',
    ori=0, pos=(0, -3.2), size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-11.0)
instructLeftSingle_leftArrowSolid = visual.ImageStim(
    win=win,
    name='instructLeftSingle_leftArrowSolid', 
    image='img/leftArrowSolid.png', mask=None, anchor='center',
    ori=0, pos=(0, -3.8), size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-12.0)

# --- Initialize components for Routine "instructMiddle" ---
instructMiddle_keyResp = keyboard.Keyboard()
instructMiddle_keyResp2 = keyboard.Keyboard()
welcome_text = visual.TextStim(win=win, name='welcome_text',
    text='',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
welcome_text2_2 = visual.TextStim(win=win, name='welcome_text2_2',
    text='',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# --- Initialize components for Routine "instructRight" ---
instructRight_text = visual.TextStim(win=win, name='instructRight_text',
    text='Below, the MIDDLE arrow is pointing to the right, so you would respond by pressing the right button with your right hand.\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructRight_centerImg = visual.ImageStim(
    win=win,
    name='instructRight_centerImg', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructRight_rightImg1 = visual.ImageStim(
    win=win,
    name='instructRight_rightImg1', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructRight_rightImg2 = visual.ImageStim(
    win=win,
    name='instructRight_rightImg2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructRight_leftImg1 = visual.ImageStim(
    win=win,
    name='instructRight_leftImg1', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructRight_leftImg2 = visual.ImageStim(
    win=win,
    name='instructRight_leftImg2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
insructRight_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "instructRight_2" ---
instructRight_text_2 = visual.TextStim(win=win, name='instructRight_text_2',
    text='Below, the MIDDLE arrow is pointing to the right, so you would respond by pressing the right button with your right hand.\n\nPress the right button to continue',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructRight_centerImg_2 = visual.ImageStim(
    win=win,
    name='instructRight_centerImg_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructRight_rightImg1_2 = visual.ImageStim(
    win=win,
    name='instructRight_rightImg1_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructRight_rightImg2_2 = visual.ImageStim(
    win=win,
    name='instructRight_rightImg2_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructRight_leftImg1_2 = visual.ImageStim(
    win=win,
    name='instructRight_leftImg1_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructRight_leftImg2_2 = visual.ImageStim(
    win=win,
    name='instructRight_leftImg2_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
insructRight_keyResp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "instructLeft" ---
instructLeft_text = visual.TextStim(win=win, name='instructLeft_text',
    text='Below, the MIDDLE arrow is pointing to the left, so you would respond by pressing the left button with your left hand.\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructLeft_centerImg = visual.ImageStim(
    win=win,
    name='instructLeft_centerImg', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructLeft_rightImg1 = visual.ImageStim(
    win=win,
    name='instructLeft_rightImg1', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructLeft_rightImg2 = visual.ImageStim(
    win=win,
    name='instructLeft_rightImg2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructLeft_leftImg1 = visual.ImageStim(
    win=win,
    name='instructLeft_leftImg1', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructLeft_leftImg2 = visual.ImageStim(
    win=win,
    name='instructLeft_leftImg2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
instructLeft_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "instructLeft_2" ---
instructLeft_text_2 = visual.TextStim(win=win, name='instructLeft_text_2',
    text='Below, the MIDDLE arrow is pointing to the left, so you would respond by pressing the left button with your left hand.\n\nPress the left button to continue',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructLeft_centerImg_2 = visual.ImageStim(
    win=win,
    name='instructLeft_centerImg_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructLeft_rightImg1_2 = visual.ImageStim(
    win=win,
    name='instructLeft_rightImg1_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructLeft_rightImg2_2 = visual.ImageStim(
    win=win,
    name='instructLeft_rightImg2_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructLeft_leftImg1_2 = visual.ImageStim(
    win=win,
    name='instructLeft_leftImg1_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructLeft_leftImg2_2 = visual.ImageStim(
    win=win,
    name='instructLeft_leftImg2_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
instructLeft_keyResp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "instructInconRight" ---
instructInconRight_text = visual.TextStim(win=win, name='instructInconRight_text',
    text='Sometimes the MIDDLE arrow will point in a different direction from the other arrows. However, your goal is to always respond to the MIDDLE arrow.\n\nBelow, the MIDDLE arrow is pointing to the right, so you would respond by pressing the right button with your right hand.\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructIncon_centerImg = visual.ImageStim(
    win=win,
    name='instructIncon_centerImg', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructIncon_rightImg1 = visual.ImageStim(
    win=win,
    name='instructIncon_rightImg1', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructIncon_rightImg2 = visual.ImageStim(
    win=win,
    name='instructIncon_rightImg2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructIncon_leftImg1 = visual.ImageStim(
    win=win,
    name='instructIncon_leftImg1', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructInconRight_leftImg2 = visual.ImageStim(
    win=win,
    name='instructInconRight_leftImg2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
insructInconRight_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "instructInconRight_2" ---
instructInconRight_text_2 = visual.TextStim(win=win, name='instructInconRight_text_2',
    text='Sometimes the MIDDLE arrow will point in a different direction from the other arrows. However, your goal is to always respond to the MIDDLE arrow.\n\nBelow, the MIDDLE arrow is pointing to the right, so you would respond by pressing the right button with your right hand.\n\nPress the right button to continue',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructIncon_centerImg_2 = visual.ImageStim(
    win=win,
    name='instructIncon_centerImg_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructIncon_rightImg1_2 = visual.ImageStim(
    win=win,
    name='instructIncon_rightImg1_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructIncon_rightImg2_2 = visual.ImageStim(
    win=win,
    name='instructIncon_rightImg2_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructIncon_leftImg1_2 = visual.ImageStim(
    win=win,
    name='instructIncon_leftImg1_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructInconRight_leftImg2_2 = visual.ImageStim(
    win=win,
    name='instructInconRight_leftImg2_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
insructInconRight_keyResp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "instructInconLeft" ---
instructInconLeft_text = visual.TextStim(win=win, name='instructInconLeft_text',
    text='Below, the MIDDLE arrow is pointing to the left, so you would respond by pressing the left button with your left hand.\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructInconLeft_centerImg = visual.ImageStim(
    win=win,
    name='instructInconLeft_centerImg', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructInconLeft_rightImg1 = visual.ImageStim(
    win=win,
    name='instructInconLeft_rightImg1', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructInconLeft_rightImg2 = visual.ImageStim(
    win=win,
    name='instructInconLeft_rightImg2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructInconLeft_leftImg1 = visual.ImageStim(
    win=win,
    name='instructInconLeft_leftImg1', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructInconLeft_leftImg2 = visual.ImageStim(
    win=win,
    name='instructInconLeft_leftImg2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
instructInconLeft_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "instructInconLeft_2" ---
instructInconLeft_text_2 = visual.TextStim(win=win, name='instructInconLeft_text_2',
    text='Below, the MIDDLE arrow is pointing to the left, so you would respond by pressing the left button with your left hand.\n\nPress the left button to continue',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
instructInconLeft_centerImg_2 = visual.ImageStim(
    win=win,
    name='instructInconLeft_centerImg_2', 
    image='img/leftArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_center_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-1.0)
instructInconLeft_rightImg1_2 = visual.ImageStim(
    win=win,
    name='instructInconLeft_rightImg1_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-2.0)
instructInconLeft_rightImg2_2 = visual.ImageStim(
    win=win,
    name='instructInconLeft_rightImg2_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_right2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-3.0)
instructInconLeft_leftImg1_2 = visual.ImageStim(
    win=win,
    name='instructInconLeft_leftImg1_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left1_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
instructInconLeft_leftImg2_2 = visual.ImageStim(
    win=win,
    name='instructInconLeft_leftImg2_2', 
    image='img/rightArrow.png', mask=None, anchor='center',
    ori=0, pos=instruct_left2_arrow_location, size=arrow_size,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
instructInconLeft_keyResp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "respond_onceInstruct" ---
respond_once_text = visual.TextStim(win=win, name='respond_once_text',
    text='Each time you see the arrows appear, respond as quickly as you can without making mistakes.\n\nHowever, only respond once each time you see the arrows appear. Even if you think you made the wrong response, do not respond again until you see the next set of arrows appear.\n\nExperimenter: demonstrate how to respond',
    font='Open Sans',
    pos=(0, 0), height=0.8, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=0.0);
respond_once_key_resp1 = keyboard.Keyboard()

# --- Initialize components for Routine "eeg_trigger_check" ---
# Run 'Begin Experiment' code from triggerCheck_code
#initialize usb connected variable
usbConnected = 1
triggerIssue_text = visual.TextStim(win=win, name='triggerIssue_text',
    text='EEG EQUIPMENT ISSUE: please ring bell for experimenter',
    font='Open Sans',
    pos=(0, 0), height=0.4, wrapWidth=12.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "prac_blockReminders" ---
# Run 'Begin Experiment' code from prac_initAcc_code
#initialize the following variables at the start of experiment
trialNum = 0
accuracy = 0
numCorr = 0
blockAcc = 0
prac_blockText = visual.TextStim(win=win, name='prac_blockText',
    text='Practice',
    font='Arial',
    pos=(0, 3), height=1.2, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
prac_reminder_text = visual.TextStim(win=win, name='prac_reminder_text',
    text='Remember to limit blinking to about once every ten seconds. Try to relax the muscles in your face, neck, and shoulders. \n\nRespond as quickly as you can without making mistakes. Only respond once each time you see the arrows appear.\n\nAlways respond to the direction of the MIDDLE arrow.\n\nTo get ready, rest your thumbs on the right and left buttons.\n\n',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
prac_reminder_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "prac_blockReminders_2" ---
prac_blockText_2 = visual.TextStim(win=win, name='prac_blockText_2',
    text='Practice',
    font='Arial',
    pos=(0, 3), height=1.2, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
prac_reminder_text_2 = visual.TextStim(win=win, name='prac_reminder_text_2',
    text='Remember to limit blinking to about once every ten seconds. Try to relax the muscles in your face, neck, and shoulders. \n\nRespond as quickly as you can without making mistakes. Only respond once each time you see the arrows appear.\n\nAlways respond to the direction of the MIDDLE arrow.\n\nTo get ready, rest your thumbs on the right and left buttons.\n\nPress the right button to begin.',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
prac_reminder_keyResp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "initFixation" ---
initFixation_img = visual.ImageStim(
    win=win,
    name='initFixation_img', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=(0, -.015), size=(0.26, 0.22),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=0.0)

# --- Initialize components for Routine "prac_stimRoutine" ---
# Run 'Begin Experiment' code from prac_isi_code
#initialize the thisISI variable
thisISI = 0
prac_background_face = visual.ImageStim(
    win=win,
    name='prac_background_face', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0.0, 0.0), size=(5.89, 4.081),
    color=[1,1,1], colorSpace='rgb', opacity=0.85,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
prac_cover_background = visual.ImageStim(
    win=win,
    name='prac_cover_background', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, -.21), size=(3.597, 3.04),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)
prac_centerImg = visual.ImageStim(
    win=win,
    name='prac_centerImg', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
prac_rightImg1 = visual.ImageStim(
    win=win,
    name='prac_rightImg1', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
prac_rightImg2 = visual.ImageStim(
    win=win,
    name='prac_rightImg2', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-6.0)
prac_leftImg1 = visual.ImageStim(
    win=win,
    name='prac_leftImg1', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-7.0)
prac_leftImg2 = visual.ImageStim(
    win=win,
    name='prac_leftImg2', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-8.0)
prac_fixImg = visual.ImageStim(
    win=win,
    name='prac_fixImg', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=(0, -.21), size=(3.597, 3.04),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-9.0)
prac_stim_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "prac_blockFeed" ---
prac_blockFeed_text = visual.TextStim(win=win, name='prac_blockFeed_text',
    text='',
    font='Arial',
    pos=(0, 1), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
prac_pressContinue = visual.TextStim(win=win, name='prac_pressContinue',
    text='Experimenter: press key to continue',
    font='Arial',
    pos=(0, -1), height=0.8, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
prac_blockFeed_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "eeg_trigger_check" ---
# Run 'Begin Experiment' code from triggerCheck_code
#initialize usb connected variable
usbConnected = 1
triggerIssue_text = visual.TextStim(win=win, name='triggerIssue_text',
    text='EEG EQUIPMENT ISSUE: please ring bell for experimenter',
    font='Open Sans',
    pos=(0, 0), height=0.4, wrapWidth=12.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "task_blockReminders" ---
# Run 'Begin Experiment' code from task_blockReminder_code
#initialize the following variables at the start of experiment
blockCounter = 0

#note that we do not need to initialize the accuracy and numCorr vars here
#because they were already initialilzed in the code snippet of the practice loop
task_blockText = visual.TextStim(win=win, name='task_blockText',
    text='',
    font='Arial',
    pos=(0, 3), height=1.2, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
task_blockReminders_text = visual.TextStim(win=win, name='task_blockReminders_text',
    text='Remember to limit blinking to about once every ten seconds. Try to relax the muscles in your face, neck, and shoulders. \n\nRespond as quickly as you can without making mistakes. Only respond once each time you see the arrows appear.\n\nAlways respond to the direction of the MIDDLE arrow.\n\nTo get ready, rest your thumbs on the right and left buttons.\n\nPress the right button to begin.',
    font='Arial',
    pos=(0, 0), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
task_blockReminders_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "initFixation" ---
initFixation_img = visual.ImageStim(
    win=win,
    name='initFixation_img', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=(0, -.015), size=(0.26, 0.22),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=0.0)

# --- Initialize components for Routine "task_stimRoutine" ---
# Run 'Begin Experiment' code from task_isi_code
#no need to initialize thisISI, as already done in practice code snippit
main_background_face = visual.ImageStim(
    win=win,
    name='main_background_face', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0.0, 0.0), size=(5.89, 4.081),
    color=[1,1,1], colorSpace='rgb', opacity=0.85,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
main_cover_background = visual.ImageStim(
    win=win,
    name='main_cover_background', 
    image='img/cover_background.png', mask=None, anchor='center',
    ori=0.0, pos=(0, -.21), size=(3.597, 3.04),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)
task_centerImg = visual.ImageStim(
    win=win,
    name='task_centerImg', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-4.0)
task_rightImg1 = visual.ImageStim(
    win=win,
    name='task_rightImg1', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-5.0)
task_rightImg2 = visual.ImageStim(
    win=win,
    name='task_rightImg2', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-6.0)
task_leftImg1 = visual.ImageStim(
    win=win,
    name='task_leftImg1', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-7.0)
task_leftImg2 = visual.ImageStim(
    win=win,
    name='task_leftImg2', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,0], size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-8.0)
task_fixImg = visual.ImageStim(
    win=win,
    name='task_fixImg', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=(0, -.21), size=(3.597, 3.04),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=True, depth=-9.0)
task1_stim_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "task_blockFeed" ---
task_blockFeed_text = visual.TextStim(win=win, name='task_blockFeed_text',
    text='',
    font='Arial',
    pos=(0, 1), height=1.2, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
task_blockFeed_text2 = visual.TextStim(win=win, name='task_blockFeed_text2',
    text='',
    font='Arial',
    pos=(0, -1), height=0.4, wrapWidth=12, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
task_blockFeed_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "fixation1" ---
fix = visual.TextStim(win=win, name='fix',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "errorNumbers" ---
errorNumbers_text = visual.TextStim(win=win, name='errorNumbers_text',
    text='Excluding the practice, how many errors do you think you made during the arrow game? \n\nPlease provide a number as your best estimate.\n\n\n\n\n\n\nExperimenter: Enter the response and then proceed by pressting the key.',
    font='Open Sans',
    pos=(0, 0.258), height=0.8, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
errorNum_box = visual.TextBox2(
     win, text=None, font='Open Sans',
     pos=(0, -0.3),     letterHeight=0.5,
     size=(6, 1), borderWidth=2.0,
     color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb',
     opacity=None,
     bold=True, italic=False,
     lineSpacing=1.0,
     padding=0.0, alignment='center',
     anchor='bottom-center',
     fillColor=[1.0000, 1.0000, 1.0000], borderColor=[-1.0000, -1.0000, -1.0000],
     flipHoriz=False, flipVert=False, languageStyle='LTR',
     editable=True,
     name='errorNum_box',
     autoLog=True,
)
errorNums_key_resp = keyboard.Keyboard()

# --- Initialize components for Routine "surpriseInstruct" ---
instruct_surp1 = visual.TextStim(win=win, name='instruct_surp1',
    text='You will now begin a game in which you will be shown images of faces and asked if you have seen them during the arrow game or not.\n\n\nFor example, if you think that you have seen a displayed face image in the previous arrow game, you should select OLD as your response.\n\nAlso, if you think you have not seen it in the previous arrow game, you should select NEW as your response. \n\n',
    font='Open Sans',
    pos=(0, 0), height=0.8, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
instruct_surp_key_resp1 = keyboard.Keyboard()

# --- Initialize components for Routine "surpriseInstruct2" ---
instruct_surp2 = visual.TextStim(win=win, name='instruct_surp2',
    text='You will now begin a game in which you will be shown images of faces and asked if you have seen them during the arrow game or not.\n\n\nFor example, if you think that you have seen a displayed face image in the previous arrow game, you should select OLD as your response.\n\nAlso, if you think you have not seen it in the previous arrow game, you should select NEW as your response. \n\n\n\nWhen you are ready, press the right button to begin.',
    font='Open Sans',
    pos=(0, 0), height=0.8, wrapWidth=24.0, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
instruct_surp_key_resp2 = keyboard.Keyboard()

# --- Initialize components for Routine "surpriseInstruct3" ---
# Run 'Begin Experiment' code from shuffling_surprise

#initialize the following variables at the start of experiment
blockCounterZ1 = 0
instruct_surp3_1 = visual.TextStim(win=win, name='instruct_surp3_1',
    text='',
    font='Arial',
    pos=(0, 1), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
instruct_surp3_2 = visual.TextStim(win=win, name='instruct_surp3_2',
    text='',
    font='Arial',
    pos=(0, -1), height=0.8, wrapWidth=24, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-2.0);
instructMainTask_keyResp = keyboard.Keyboard()

# --- Initialize components for Routine "fixation2" ---
fix2 = visual.TextStim(win=win, name='fix2',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "surpriseTask" ---
stimulus = visual.ImageStim(
    win=win,
    name='stimulus', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0.0, 2.5), size=(10.615, 6.96),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instructsurpA1_right = visual.TextStim(win=win, name='instructsurpA1_right',
    text='',
    font='Open Sans',
    pos=[0,0], height=0.4, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
instructsurpA2_left = visual.TextStim(win=win, name='instructsurpA2_left',
    text='',
    font='Open Sans',
    pos=(-9, -0.5), height=0.4, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
surprise_key_resp = keyboard.Keyboard()

# --- Initialize components for Routine "fixation2" ---
fix2 = visual.TextStim(win=win, name='fix2',
    text='+',
    font='Open Sans',
    pos=(0, 0), height=1.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "finishMessage" ---
finishMessage_text = visual.TextStim(win=win, name='finishMessage_text',
    text='Thank you for your participation!',
    font='Arial',
    pos=(0, 0), height=0.4, wrapWidth=12, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "JS_code" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# keep track of which components have finished
JS_codeComponents = []
for thisComponent in JS_codeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "JS_code" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in JS_codeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "JS_code" ---
for thisComponent in JS_codeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "JS_code" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "setup" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# keep track of which components have finished
setupComponents = []
for thisComponent in setupComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "setup" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in setupComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "setup" ---
for thisComponent in setupComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "setup" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "welcome" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
welcome_keyResp.keys = []
welcome_keyResp.rt = []
_welcome_keyResp_allKeys = []
welcome_keyResp2.keys = []
welcome_keyResp2.rt = []
_welcome_keyResp2_allKeys = []
welcome_text1.setText('Arrow Game \n\nWelcome to the Arrow game. In this game, arrows will be quickly flashed on the screen. Your goal is to respond to the direction of the arrows, and to respond as quickly as you can without making mistakes. \n\n\n')
welcome_text2.setText('Arrow Game \n\nWelcome to the Arrow game. In this game, arrows will be quickly flashed on the screen. Your goal is to respond to the direction of the arrows, and to respond as quickly as you can without making mistakes. \n\nPress the right button to continue\n')
# keep track of which components have finished
welcomeComponents = [welcome_keyResp, welcome_keyResp2, welcome_text1, welcome_text2]
for thisComponent in welcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "welcome" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welcome_keyResp* updates
    waitOnFlip = False
    if welcome_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        welcome_keyResp.frameNStart = frameN  # exact frame index
        welcome_keyResp.tStart = t  # local t and not account for scr refresh
        welcome_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_keyResp, 'tStartRefresh')  # time at next scr refresh
        welcome_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(welcome_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(welcome_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if welcome_keyResp.status == STARTED:
        if bool(welcome_keyResp.keys):
            # keep track of stop time/frame for later
            welcome_keyResp.tStop = t  # not accounting for scr refresh
            welcome_keyResp.frameNStop = frameN  # exact frame index
            welcome_keyResp.status = FINISHED
    if welcome_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = welcome_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _welcome_keyResp_allKeys.extend(theseKeys)
        if len(_welcome_keyResp_allKeys):
            welcome_keyResp.keys = _welcome_keyResp_allKeys[-1].name  # just the last key pressed
            welcome_keyResp.rt = _welcome_keyResp_allKeys[-1].rt
    
    # *welcome_keyResp2* updates
    if welcome_keyResp2.status == NOT_STARTED and welcome_keyResp.keys:
        # keep track of start time/frame for later
        welcome_keyResp2.frameNStart = frameN  # exact frame index
        welcome_keyResp2.tStart = t  # local t and not account for scr refresh
        welcome_keyResp2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_keyResp2, 'tStartRefresh')  # time at next scr refresh
        welcome_keyResp2.status = STARTED
        # keyboard checking is just starting
        welcome_keyResp2.clock.reset()  # now t=0
        welcome_keyResp2.clearEvents(eventType='keyboard')
    if welcome_keyResp2.status == STARTED:
        theseKeys = welcome_keyResp2.getKeys(keyList=['8'], waitRelease=False)
        _welcome_keyResp2_allKeys.extend(theseKeys)
        if len(_welcome_keyResp2_allKeys):
            welcome_keyResp2.keys = _welcome_keyResp2_allKeys[-1].name  # just the last key pressed
            welcome_keyResp2.rt = _welcome_keyResp2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *welcome_text1* updates
    if welcome_text1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        welcome_text1.frameNStart = frameN  # exact frame index
        welcome_text1.tStart = t  # local t and not account for scr refresh
        welcome_text1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_text1, 'tStartRefresh')  # time at next scr refresh
        welcome_text1.setAutoDraw(True)
    
    # *welcome_text2* updates
    if welcome_text2.status == NOT_STARTED and welcome_keyResp.keys:
        # keep track of start time/frame for later
        welcome_text2.frameNStart = frameN  # exact frame index
        welcome_text2.tStart = t  # local t and not account for scr refresh
        welcome_text2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_text2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'welcome_text2.started')
        welcome_text2.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in welcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "welcome" ---
for thisComponent in welcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "welcome" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructRightSingle" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instructRightSingle_keyResp.keys = []
instructRightSingle_keyResp.rt = []
_instructRightSingle_keyResp_allKeys = []
instructRightSingle_keyResp_2.keys = []
instructRightSingle_keyResp_2.rt = []
_instructRightSingle_keyResp_2_allKeys = []
instructRightSingle_keyResp_3.keys = []
instructRightSingle_keyResp_3.rt = []
_instructRightSingle_keyResp_3_allKeys = []
instructRightSingle_keyResp_4.keys = []
instructRightSingle_keyResp_4.rt = []
_instructRightSingle_keyResp_4_allKeys = []
instructRightSingle_keyResp_5.keys = []
instructRightSingle_keyResp_5.rt = []
_instructRightSingle_keyResp_5_allKeys = []
# keep track of which components have finished
instructRightSingleComponents = [instructRightSingle_keyResp, instructRightSingle_keyResp_2, instructRightSingle_keyResp_3, instructRightSingle_keyResp_4, instructRightSingle_keyResp_5, instructRightSingle_text, instructRightSingle_text_2, instructRightSingle_text_3, instructRightSingle_text_4, instructRightSingle_text_5, instructRightSingle_rightArrow, instructRightSingle_rightArrowHighlight, instructRightSingle_rightArrowSolid]
for thisComponent in instructRightSingleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructRightSingle" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructRightSingle_keyResp* updates
    waitOnFlip = False
    if instructRightSingle_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRightSingle_keyResp.frameNStart = frameN  # exact frame index
        instructRightSingle_keyResp.tStart = t  # local t and not account for scr refresh
        instructRightSingle_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_keyResp, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructRightSingle_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructRightSingle_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructRightSingle_keyResp.status == STARTED:
        if bool(instructRightSingle_keyResp.keys):
            # keep track of stop time/frame for later
            instructRightSingle_keyResp.tStop = t  # not accounting for scr refresh
            instructRightSingle_keyResp.frameNStop = frameN  # exact frame index
            instructRightSingle_keyResp.status = FINISHED
    if instructRightSingle_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = instructRightSingle_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _instructRightSingle_keyResp_allKeys.extend(theseKeys)
        if len(_instructRightSingle_keyResp_allKeys):
            instructRightSingle_keyResp.keys = _instructRightSingle_keyResp_allKeys[-1].name  # just the last key pressed
            instructRightSingle_keyResp.rt = _instructRightSingle_keyResp_allKeys[-1].rt
    
    # *instructRightSingle_keyResp_2* updates
    waitOnFlip = False
    if instructRightSingle_keyResp_2.status == NOT_STARTED and instructRightSingle_keyResp.keys:
        # keep track of start time/frame for later
        instructRightSingle_keyResp_2.frameNStart = frameN  # exact frame index
        instructRightSingle_keyResp_2.tStart = t  # local t and not account for scr refresh
        instructRightSingle_keyResp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_keyResp_2, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_keyResp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructRightSingle_keyResp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructRightSingle_keyResp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructRightSingle_keyResp_2.status == STARTED:
        if bool(instructRightSingle_keyResp_2.keys):
            # keep track of stop time/frame for later
            instructRightSingle_keyResp_2.tStop = t  # not accounting for scr refresh
            instructRightSingle_keyResp_2.frameNStop = frameN  # exact frame index
            instructRightSingle_keyResp_2.status = FINISHED
    if instructRightSingle_keyResp_2.status == STARTED and not waitOnFlip:
        theseKeys = instructRightSingle_keyResp_2.getKeys(keyList=['c'], waitRelease=False)
        _instructRightSingle_keyResp_2_allKeys.extend(theseKeys)
        if len(_instructRightSingle_keyResp_2_allKeys):
            instructRightSingle_keyResp_2.keys = _instructRightSingle_keyResp_2_allKeys[-1].name  # just the last key pressed
            instructRightSingle_keyResp_2.rt = _instructRightSingle_keyResp_2_allKeys[-1].rt
    
    # *instructRightSingle_keyResp_3* updates
    waitOnFlip = False
    if instructRightSingle_keyResp_3.status == NOT_STARTED and instructRightSingle_keyResp_2.keys:
        # keep track of start time/frame for later
        instructRightSingle_keyResp_3.frameNStart = frameN  # exact frame index
        instructRightSingle_keyResp_3.tStart = t  # local t and not account for scr refresh
        instructRightSingle_keyResp_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_keyResp_3, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_keyResp_3.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructRightSingle_keyResp_3.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructRightSingle_keyResp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructRightSingle_keyResp_3.status == STARTED:
        if bool(instructRightSingle_keyResp_3.keys):
            # keep track of stop time/frame for later
            instructRightSingle_keyResp_3.tStop = t  # not accounting for scr refresh
            instructRightSingle_keyResp_3.frameNStop = frameN  # exact frame index
            instructRightSingle_keyResp_3.status = FINISHED
    if instructRightSingle_keyResp_3.status == STARTED and not waitOnFlip:
        theseKeys = instructRightSingle_keyResp_3.getKeys(keyList=['c'], waitRelease=False)
        _instructRightSingle_keyResp_3_allKeys.extend(theseKeys)
        if len(_instructRightSingle_keyResp_3_allKeys):
            instructRightSingle_keyResp_3.keys = _instructRightSingle_keyResp_3_allKeys[-1].name  # just the last key pressed
            instructRightSingle_keyResp_3.rt = _instructRightSingle_keyResp_3_allKeys[-1].rt
    
    # *instructRightSingle_keyResp_4* updates
    waitOnFlip = False
    if instructRightSingle_keyResp_4.status == NOT_STARTED and instructRightSingle_keyResp_3.keys:
        # keep track of start time/frame for later
        instructRightSingle_keyResp_4.frameNStart = frameN  # exact frame index
        instructRightSingle_keyResp_4.tStart = t  # local t and not account for scr refresh
        instructRightSingle_keyResp_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_keyResp_4, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_keyResp_4.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructRightSingle_keyResp_4.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructRightSingle_keyResp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructRightSingle_keyResp_4.status == STARTED:
        if bool(instructRightSingle_keyResp_4.keys):
            # keep track of stop time/frame for later
            instructRightSingle_keyResp_4.tStop = t  # not accounting for scr refresh
            instructRightSingle_keyResp_4.frameNStop = frameN  # exact frame index
            instructRightSingle_keyResp_4.status = FINISHED
    if instructRightSingle_keyResp_4.status == STARTED and not waitOnFlip:
        theseKeys = instructRightSingle_keyResp_4.getKeys(keyList=['c'], waitRelease=False)
        _instructRightSingle_keyResp_4_allKeys.extend(theseKeys)
        if len(_instructRightSingle_keyResp_4_allKeys):
            instructRightSingle_keyResp_4.keys = _instructRightSingle_keyResp_4_allKeys[-1].name  # just the last key pressed
            instructRightSingle_keyResp_4.rt = _instructRightSingle_keyResp_4_allKeys[-1].rt
    
    # *instructRightSingle_keyResp_5* updates
    waitOnFlip = False
    if instructRightSingle_keyResp_5.status == NOT_STARTED and instructRightSingle_keyResp_4.keys:
        # keep track of start time/frame for later
        instructRightSingle_keyResp_5.frameNStart = frameN  # exact frame index
        instructRightSingle_keyResp_5.tStart = t  # local t and not account for scr refresh
        instructRightSingle_keyResp_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_keyResp_5, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_keyResp_5.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructRightSingle_keyResp_5.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructRightSingle_keyResp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructRightSingle_keyResp_5.status == STARTED:
        if bool(instructRightSingle_keyResp_5.keys):
            # keep track of stop time/frame for later
            instructRightSingle_keyResp_5.tStop = t  # not accounting for scr refresh
            instructRightSingle_keyResp_5.frameNStop = frameN  # exact frame index
            instructRightSingle_keyResp_5.status = FINISHED
    if instructRightSingle_keyResp_5.status == STARTED and not waitOnFlip:
        theseKeys = instructRightSingle_keyResp_5.getKeys(keyList=['8'], waitRelease=False)
        _instructRightSingle_keyResp_5_allKeys.extend(theseKeys)
        if len(_instructRightSingle_keyResp_5_allKeys):
            instructRightSingle_keyResp_5.keys = _instructRightSingle_keyResp_5_allKeys[-1].name  # just the last key pressed
            instructRightSingle_keyResp_5.rt = _instructRightSingle_keyResp_5_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *instructRightSingle_text* updates
    if instructRightSingle_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRightSingle_text.frameNStart = frameN  # exact frame index
        instructRightSingle_text.tStart = t  # local t and not account for scr refresh
        instructRightSingle_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_text, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_text.setAutoDraw(True)
    
    # *instructRightSingle_text_2* updates
    if instructRightSingle_text_2.status == NOT_STARTED and instructRightSingle_keyResp.keys:
        # keep track of start time/frame for later
        instructRightSingle_text_2.frameNStart = frameN  # exact frame index
        instructRightSingle_text_2.tStart = t  # local t and not account for scr refresh
        instructRightSingle_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_text_2, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_text_2.setAutoDraw(True)
    
    # *instructRightSingle_text_3* updates
    if instructRightSingle_text_3.status == NOT_STARTED and instructRightSingle_keyResp_2.keys:
        # keep track of start time/frame for later
        instructRightSingle_text_3.frameNStart = frameN  # exact frame index
        instructRightSingle_text_3.tStart = t  # local t and not account for scr refresh
        instructRightSingle_text_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_text_3, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_text_3.setAutoDraw(True)
    
    # *instructRightSingle_text_4* updates
    if instructRightSingle_text_4.status == NOT_STARTED and instructRightSingle_keyResp_3.keys:
        # keep track of start time/frame for later
        instructRightSingle_text_4.frameNStart = frameN  # exact frame index
        instructRightSingle_text_4.tStart = t  # local t and not account for scr refresh
        instructRightSingle_text_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_text_4, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_text_4.setAutoDraw(True)
    
    # *instructRightSingle_text_5* updates
    if instructRightSingle_text_5.status == NOT_STARTED and instructRightSingle_keyResp_4.keys:
        # keep track of start time/frame for later
        instructRightSingle_text_5.frameNStart = frameN  # exact frame index
        instructRightSingle_text_5.tStart = t  # local t and not account for scr refresh
        instructRightSingle_text_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_text_5, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_text_5.setAutoDraw(True)
    
    # *instructRightSingle_rightArrow* updates
    if instructRightSingle_rightArrow.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRightSingle_rightArrow.frameNStart = frameN  # exact frame index
        instructRightSingle_rightArrow.tStart = t  # local t and not account for scr refresh
        instructRightSingle_rightArrow.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_rightArrow, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_rightArrow.setAutoDraw(True)
    
    # *instructRightSingle_rightArrowHighlight* updates
    if instructRightSingle_rightArrowHighlight.status == NOT_STARTED and instructRightSingle_keyResp.keys:
        # keep track of start time/frame for later
        instructRightSingle_rightArrowHighlight.frameNStart = frameN  # exact frame index
        instructRightSingle_rightArrowHighlight.tStart = t  # local t and not account for scr refresh
        instructRightSingle_rightArrowHighlight.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_rightArrowHighlight, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_rightArrowHighlight.setAutoDraw(True)
    
    # *instructRightSingle_rightArrowSolid* updates
    if instructRightSingle_rightArrowSolid.status == NOT_STARTED and instructRightSingle_keyResp_2.keys:
        # keep track of start time/frame for later
        instructRightSingle_rightArrowSolid.frameNStart = frameN  # exact frame index
        instructRightSingle_rightArrowSolid.tStart = t  # local t and not account for scr refresh
        instructRightSingle_rightArrowSolid.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRightSingle_rightArrowSolid, 'tStartRefresh')  # time at next scr refresh
        instructRightSingle_rightArrowSolid.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructRightSingleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructRightSingle" ---
for thisComponent in instructRightSingleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructRightSingle" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructLeftSingle" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instructLeftSingle_keyResp.keys = []
instructLeftSingle_keyResp.rt = []
_instructLeftSingle_keyResp_allKeys = []
instructLeftSingle_keyResp_2.keys = []
instructLeftSingle_keyResp_2.rt = []
_instructLeftSingle_keyResp_2_allKeys = []
instructLeftSingle_keyResp_3.keys = []
instructLeftSingle_keyResp_3.rt = []
_instructLeftSingle_keyResp_3_allKeys = []
instructLeftSingle_keyResp_4.keys = []
instructLeftSingle_keyResp_4.rt = []
_instructLeftSingle_keyResp_4_allKeys = []
instructLeftSingle_keyResp_5.keys = []
instructLeftSingle_keyResp_5.rt = []
_instructLeftSingle_keyResp_5_allKeys = []
# keep track of which components have finished
instructLeftSingleComponents = [instructLeftSingle_keyResp, instructLeftSingle_keyResp_2, instructLeftSingle_keyResp_3, instructLeftSingle_keyResp_4, instructLeftSingle_keyResp_5, instructLeftSingle_text, instructLeftSingle_text_2, instructLeftSingle_text_3, instructLeftSingle_text_4, instructLeftSingle_text_5, instructLeftSingle_leftArrow, instructLeftSingle_leftArrowHighlight, instructLeftSingle_leftArrowSolid]
for thisComponent in instructLeftSingleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructLeftSingle" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructLeftSingle_keyResp* updates
    waitOnFlip = False
    if instructLeftSingle_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeftSingle_keyResp.frameNStart = frameN  # exact frame index
        instructLeftSingle_keyResp.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_keyResp, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructLeftSingle_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructLeftSingle_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructLeftSingle_keyResp.status == STARTED:
        if bool(instructLeftSingle_keyResp.keys):
            # keep track of stop time/frame for later
            instructLeftSingle_keyResp.tStop = t  # not accounting for scr refresh
            instructLeftSingle_keyResp.frameNStop = frameN  # exact frame index
            instructLeftSingle_keyResp.status = FINISHED
    if instructLeftSingle_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = instructLeftSingle_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _instructLeftSingle_keyResp_allKeys.extend(theseKeys)
        if len(_instructLeftSingle_keyResp_allKeys):
            instructLeftSingle_keyResp.keys = _instructLeftSingle_keyResp_allKeys[-1].name  # just the last key pressed
            instructLeftSingle_keyResp.rt = _instructLeftSingle_keyResp_allKeys[-1].rt
    
    # *instructLeftSingle_keyResp_2* updates
    waitOnFlip = False
    if instructLeftSingle_keyResp_2.status == NOT_STARTED and instructLeftSingle_keyResp.keys:
        # keep track of start time/frame for later
        instructLeftSingle_keyResp_2.frameNStart = frameN  # exact frame index
        instructLeftSingle_keyResp_2.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_keyResp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_keyResp_2, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_keyResp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructLeftSingle_keyResp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructLeftSingle_keyResp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructLeftSingle_keyResp_2.status == STARTED:
        if bool(instructLeftSingle_keyResp_2.keys):
            # keep track of stop time/frame for later
            instructLeftSingle_keyResp_2.tStop = t  # not accounting for scr refresh
            instructLeftSingle_keyResp_2.frameNStop = frameN  # exact frame index
            instructLeftSingle_keyResp_2.status = FINISHED
    if instructLeftSingle_keyResp_2.status == STARTED and not waitOnFlip:
        theseKeys = instructLeftSingle_keyResp_2.getKeys(keyList=['c'], waitRelease=False)
        _instructLeftSingle_keyResp_2_allKeys.extend(theseKeys)
        if len(_instructLeftSingle_keyResp_2_allKeys):
            instructLeftSingle_keyResp_2.keys = _instructLeftSingle_keyResp_2_allKeys[-1].name  # just the last key pressed
            instructLeftSingle_keyResp_2.rt = _instructLeftSingle_keyResp_2_allKeys[-1].rt
    
    # *instructLeftSingle_keyResp_3* updates
    waitOnFlip = False
    if instructLeftSingle_keyResp_3.status == NOT_STARTED and instructLeftSingle_keyResp_2.keys:
        # keep track of start time/frame for later
        instructLeftSingle_keyResp_3.frameNStart = frameN  # exact frame index
        instructLeftSingle_keyResp_3.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_keyResp_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_keyResp_3, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_keyResp_3.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructLeftSingle_keyResp_3.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructLeftSingle_keyResp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructLeftSingle_keyResp_3.status == STARTED:
        if bool(instructLeftSingle_keyResp_3.keys):
            # keep track of stop time/frame for later
            instructLeftSingle_keyResp_3.tStop = t  # not accounting for scr refresh
            instructLeftSingle_keyResp_3.frameNStop = frameN  # exact frame index
            instructLeftSingle_keyResp_3.status = FINISHED
    if instructLeftSingle_keyResp_3.status == STARTED and not waitOnFlip:
        theseKeys = instructLeftSingle_keyResp_3.getKeys(keyList=['c'], waitRelease=False)
        _instructLeftSingle_keyResp_3_allKeys.extend(theseKeys)
        if len(_instructLeftSingle_keyResp_3_allKeys):
            instructLeftSingle_keyResp_3.keys = _instructLeftSingle_keyResp_3_allKeys[-1].name  # just the last key pressed
            instructLeftSingle_keyResp_3.rt = _instructLeftSingle_keyResp_3_allKeys[-1].rt
    
    # *instructLeftSingle_keyResp_4* updates
    waitOnFlip = False
    if instructLeftSingle_keyResp_4.status == NOT_STARTED and instructLeftSingle_keyResp_3.keys:
        # keep track of start time/frame for later
        instructLeftSingle_keyResp_4.frameNStart = frameN  # exact frame index
        instructLeftSingle_keyResp_4.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_keyResp_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_keyResp_4, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_keyResp_4.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructLeftSingle_keyResp_4.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructLeftSingle_keyResp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructLeftSingle_keyResp_4.status == STARTED:
        if bool(instructLeftSingle_keyResp_4.keys):
            # keep track of stop time/frame for later
            instructLeftSingle_keyResp_4.tStop = t  # not accounting for scr refresh
            instructLeftSingle_keyResp_4.frameNStop = frameN  # exact frame index
            instructLeftSingle_keyResp_4.status = FINISHED
    if instructLeftSingle_keyResp_4.status == STARTED and not waitOnFlip:
        theseKeys = instructLeftSingle_keyResp_4.getKeys(keyList=['c'], waitRelease=False)
        _instructLeftSingle_keyResp_4_allKeys.extend(theseKeys)
        if len(_instructLeftSingle_keyResp_4_allKeys):
            instructLeftSingle_keyResp_4.keys = _instructLeftSingle_keyResp_4_allKeys[-1].name  # just the last key pressed
            instructLeftSingle_keyResp_4.rt = _instructLeftSingle_keyResp_4_allKeys[-1].rt
    
    # *instructLeftSingle_keyResp_5* updates
    waitOnFlip = False
    if instructLeftSingle_keyResp_5.status == NOT_STARTED and instructLeftSingle_keyResp_4.keys:
        # keep track of start time/frame for later
        instructLeftSingle_keyResp_5.frameNStart = frameN  # exact frame index
        instructLeftSingle_keyResp_5.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_keyResp_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_keyResp_5, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_keyResp_5.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructLeftSingle_keyResp_5.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructLeftSingle_keyResp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructLeftSingle_keyResp_5.status == STARTED:
        if bool(instructLeftSingle_keyResp_5.keys):
            # keep track of stop time/frame for later
            instructLeftSingle_keyResp_5.tStop = t  # not accounting for scr refresh
            instructLeftSingle_keyResp_5.frameNStop = frameN  # exact frame index
            instructLeftSingle_keyResp_5.status = FINISHED
    if instructLeftSingle_keyResp_5.status == STARTED and not waitOnFlip:
        theseKeys = instructLeftSingle_keyResp_5.getKeys(keyList=['1'], waitRelease=False)
        _instructLeftSingle_keyResp_5_allKeys.extend(theseKeys)
        if len(_instructLeftSingle_keyResp_5_allKeys):
            instructLeftSingle_keyResp_5.keys = _instructLeftSingle_keyResp_5_allKeys[-1].name  # just the last key pressed
            instructLeftSingle_keyResp_5.rt = _instructLeftSingle_keyResp_5_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *instructLeftSingle_text* updates
    if instructLeftSingle_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeftSingle_text.frameNStart = frameN  # exact frame index
        instructLeftSingle_text.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_text, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_text.setAutoDraw(True)
    
    # *instructLeftSingle_text_2* updates
    if instructLeftSingle_text_2.status == NOT_STARTED and instructLeftSingle_keyResp.keys:
        # keep track of start time/frame for later
        instructLeftSingle_text_2.frameNStart = frameN  # exact frame index
        instructLeftSingle_text_2.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_text_2, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_text_2.setAutoDraw(True)
    
    # *instructLeftSingle_text_3* updates
    if instructLeftSingle_text_3.status == NOT_STARTED and instructLeftSingle_keyResp_2.keys:
        # keep track of start time/frame for later
        instructLeftSingle_text_3.frameNStart = frameN  # exact frame index
        instructLeftSingle_text_3.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_text_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_text_3, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_text_3.setAutoDraw(True)
    
    # *instructLeftSingle_text_4* updates
    if instructLeftSingle_text_4.status == NOT_STARTED and instructLeftSingle_keyResp_3.keys:
        # keep track of start time/frame for later
        instructLeftSingle_text_4.frameNStart = frameN  # exact frame index
        instructLeftSingle_text_4.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_text_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_text_4, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_text_4.setAutoDraw(True)
    
    # *instructLeftSingle_text_5* updates
    if instructLeftSingle_text_5.status == NOT_STARTED and instructLeftSingle_keyResp_4.keys:
        # keep track of start time/frame for later
        instructLeftSingle_text_5.frameNStart = frameN  # exact frame index
        instructLeftSingle_text_5.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_text_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_text_5, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_text_5.setAutoDraw(True)
    
    # *instructLeftSingle_leftArrow* updates
    if instructLeftSingle_leftArrow.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeftSingle_leftArrow.frameNStart = frameN  # exact frame index
        instructLeftSingle_leftArrow.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_leftArrow.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_leftArrow, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_leftArrow.setAutoDraw(True)
    
    # *instructLeftSingle_leftArrowHighlight* updates
    if instructLeftSingle_leftArrowHighlight.status == NOT_STARTED and instructLeftSingle_keyResp.keys:
        # keep track of start time/frame for later
        instructLeftSingle_leftArrowHighlight.frameNStart = frameN  # exact frame index
        instructLeftSingle_leftArrowHighlight.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_leftArrowHighlight.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_leftArrowHighlight, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_leftArrowHighlight.setAutoDraw(True)
    
    # *instructLeftSingle_leftArrowSolid* updates
    if instructLeftSingle_leftArrowSolid.status == NOT_STARTED and instructLeftSingle_keyResp_2.keys:
        # keep track of start time/frame for later
        instructLeftSingle_leftArrowSolid.frameNStart = frameN  # exact frame index
        instructLeftSingle_leftArrowSolid.tStart = t  # local t and not account for scr refresh
        instructLeftSingle_leftArrowSolid.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeftSingle_leftArrowSolid, 'tStartRefresh')  # time at next scr refresh
        instructLeftSingle_leftArrowSolid.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructLeftSingleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructLeftSingle" ---
for thisComponent in instructLeftSingleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructLeftSingle" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructMiddle" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instructMiddle_keyResp.keys = []
instructMiddle_keyResp.rt = []
_instructMiddle_keyResp_allKeys = []
instructMiddle_keyResp2.keys = []
instructMiddle_keyResp2.rt = []
_instructMiddle_keyResp2_allKeys = []
welcome_text.setText('During the game, five arrows will appear at a time. They will be quickly flashed on the screen. Your goal is to respond to the MIDDLE arrow, and to respond as quickly as you can without making mistakes. \n\nIf the MIDDLE arrow is pointing to the right, use your right hand to press the right button. If the MIDDLE arrow is pointing to the left, use your left hand to press the left button. \n\n\n')
welcome_text2_2.setText('During the game, five arrows will appear at a time. They will be quickly flashed on the screen. Your goal is to respond to the MIDDLE arrow, and to respond as quickly as you can without making mistakes. \n\nIf the MIDDLE arrow is pointing to the right, use your right hand to press the right button. If the MIDDLE arrow is pointing to the left, use your left hand to press the left button. \n\nPress the right button to continue\n')
# keep track of which components have finished
instructMiddleComponents = [instructMiddle_keyResp, instructMiddle_keyResp2, welcome_text, welcome_text2_2]
for thisComponent in instructMiddleComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructMiddle" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructMiddle_keyResp* updates
    waitOnFlip = False
    if instructMiddle_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructMiddle_keyResp.frameNStart = frameN  # exact frame index
        instructMiddle_keyResp.tStart = t  # local t and not account for scr refresh
        instructMiddle_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructMiddle_keyResp, 'tStartRefresh')  # time at next scr refresh
        instructMiddle_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructMiddle_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructMiddle_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructMiddle_keyResp.status == STARTED:
        if bool(instructMiddle_keyResp.keys):
            # keep track of stop time/frame for later
            instructMiddle_keyResp.tStop = t  # not accounting for scr refresh
            instructMiddle_keyResp.frameNStop = frameN  # exact frame index
            instructMiddle_keyResp.status = FINISHED
    if instructMiddle_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = instructMiddle_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _instructMiddle_keyResp_allKeys.extend(theseKeys)
        if len(_instructMiddle_keyResp_allKeys):
            instructMiddle_keyResp.keys = _instructMiddle_keyResp_allKeys[-1].name  # just the last key pressed
            instructMiddle_keyResp.rt = _instructMiddle_keyResp_allKeys[-1].rt
    
    # *instructMiddle_keyResp2* updates
    if instructMiddle_keyResp2.status == NOT_STARTED and instructMiddle_keyResp.keys:
        # keep track of start time/frame for later
        instructMiddle_keyResp2.frameNStart = frameN  # exact frame index
        instructMiddle_keyResp2.tStart = t  # local t and not account for scr refresh
        instructMiddle_keyResp2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructMiddle_keyResp2, 'tStartRefresh')  # time at next scr refresh
        instructMiddle_keyResp2.status = STARTED
        # keyboard checking is just starting
        instructMiddle_keyResp2.clock.reset()  # now t=0
        instructMiddle_keyResp2.clearEvents(eventType='keyboard')
    if instructMiddle_keyResp2.status == STARTED:
        theseKeys = instructMiddle_keyResp2.getKeys(keyList=['8'], waitRelease=False)
        _instructMiddle_keyResp2_allKeys.extend(theseKeys)
        if len(_instructMiddle_keyResp2_allKeys):
            instructMiddle_keyResp2.keys = _instructMiddle_keyResp2_allKeys[-1].name  # just the last key pressed
            instructMiddle_keyResp2.rt = _instructMiddle_keyResp2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # *welcome_text* updates
    if welcome_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        welcome_text.frameNStart = frameN  # exact frame index
        welcome_text.tStart = t  # local t and not account for scr refresh
        welcome_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_text, 'tStartRefresh')  # time at next scr refresh
        welcome_text.setAutoDraw(True)
    
    # *welcome_text2_2* updates
    if welcome_text2_2.status == NOT_STARTED and instructMiddle_keyResp.keys:
        # keep track of start time/frame for later
        welcome_text2_2.frameNStart = frameN  # exact frame index
        welcome_text2_2.tStart = t  # local t and not account for scr refresh
        welcome_text2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcome_text2_2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'welcome_text2_2.started')
        welcome_text2_2.setAutoDraw(True)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructMiddleComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructMiddle" ---
for thisComponent in instructMiddleComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructMiddle" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructRight" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
insructRight_keyResp.keys = []
insructRight_keyResp.rt = []
_insructRight_keyResp_allKeys = []
# keep track of which components have finished
instructRightComponents = [instructRight_text, instructRight_centerImg, instructRight_rightImg1, instructRight_rightImg2, instructRight_leftImg1, instructRight_leftImg2, insructRight_keyResp]
for thisComponent in instructRightComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructRight" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructRight_text* updates
    if instructRight_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_text.frameNStart = frameN  # exact frame index
        instructRight_text.tStart = t  # local t and not account for scr refresh
        instructRight_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_text, 'tStartRefresh')  # time at next scr refresh
        instructRight_text.setAutoDraw(True)
    
    # *instructRight_centerImg* updates
    if instructRight_centerImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_centerImg.frameNStart = frameN  # exact frame index
        instructRight_centerImg.tStart = t  # local t and not account for scr refresh
        instructRight_centerImg.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_centerImg, 'tStartRefresh')  # time at next scr refresh
        instructRight_centerImg.setAutoDraw(True)
    
    # *instructRight_rightImg1* updates
    if instructRight_rightImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_rightImg1.frameNStart = frameN  # exact frame index
        instructRight_rightImg1.tStart = t  # local t and not account for scr refresh
        instructRight_rightImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_rightImg1, 'tStartRefresh')  # time at next scr refresh
        instructRight_rightImg1.setAutoDraw(True)
    
    # *instructRight_rightImg2* updates
    if instructRight_rightImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_rightImg2.frameNStart = frameN  # exact frame index
        instructRight_rightImg2.tStart = t  # local t and not account for scr refresh
        instructRight_rightImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_rightImg2, 'tStartRefresh')  # time at next scr refresh
        instructRight_rightImg2.setAutoDraw(True)
    
    # *instructRight_leftImg1* updates
    if instructRight_leftImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_leftImg1.frameNStart = frameN  # exact frame index
        instructRight_leftImg1.tStart = t  # local t and not account for scr refresh
        instructRight_leftImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_leftImg1, 'tStartRefresh')  # time at next scr refresh
        instructRight_leftImg1.setAutoDraw(True)
    
    # *instructRight_leftImg2* updates
    if instructRight_leftImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_leftImg2.frameNStart = frameN  # exact frame index
        instructRight_leftImg2.tStart = t  # local t and not account for scr refresh
        instructRight_leftImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_leftImg2, 'tStartRefresh')  # time at next scr refresh
        instructRight_leftImg2.setAutoDraw(True)
    
    # *insructRight_keyResp* updates
    waitOnFlip = False
    if insructRight_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        insructRight_keyResp.frameNStart = frameN  # exact frame index
        insructRight_keyResp.tStart = t  # local t and not account for scr refresh
        insructRight_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(insructRight_keyResp, 'tStartRefresh')  # time at next scr refresh
        insructRight_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(insructRight_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(insructRight_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if insructRight_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = insructRight_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _insructRight_keyResp_allKeys.extend(theseKeys)
        if len(_insructRight_keyResp_allKeys):
            insructRight_keyResp.keys = _insructRight_keyResp_allKeys[-1].name  # just the last key pressed
            insructRight_keyResp.rt = _insructRight_keyResp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructRightComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructRight" ---
for thisComponent in instructRightComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructRight" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructRight_2" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
insructRight_keyResp_2.keys = []
insructRight_keyResp_2.rt = []
_insructRight_keyResp_2_allKeys = []
# keep track of which components have finished
instructRight_2Components = [instructRight_text_2, instructRight_centerImg_2, instructRight_rightImg1_2, instructRight_rightImg2_2, instructRight_leftImg1_2, instructRight_leftImg2_2, insructRight_keyResp_2]
for thisComponent in instructRight_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructRight_2" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructRight_text_2* updates
    if instructRight_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_text_2.frameNStart = frameN  # exact frame index
        instructRight_text_2.tStart = t  # local t and not account for scr refresh
        instructRight_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_text_2, 'tStartRefresh')  # time at next scr refresh
        instructRight_text_2.setAutoDraw(True)
    
    # *instructRight_centerImg_2* updates
    if instructRight_centerImg_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_centerImg_2.frameNStart = frameN  # exact frame index
        instructRight_centerImg_2.tStart = t  # local t and not account for scr refresh
        instructRight_centerImg_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_centerImg_2, 'tStartRefresh')  # time at next scr refresh
        instructRight_centerImg_2.setAutoDraw(True)
    
    # *instructRight_rightImg1_2* updates
    if instructRight_rightImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_rightImg1_2.frameNStart = frameN  # exact frame index
        instructRight_rightImg1_2.tStart = t  # local t and not account for scr refresh
        instructRight_rightImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_rightImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructRight_rightImg1_2.setAutoDraw(True)
    
    # *instructRight_rightImg2_2* updates
    if instructRight_rightImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_rightImg2_2.frameNStart = frameN  # exact frame index
        instructRight_rightImg2_2.tStart = t  # local t and not account for scr refresh
        instructRight_rightImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_rightImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructRight_rightImg2_2.setAutoDraw(True)
    
    # *instructRight_leftImg1_2* updates
    if instructRight_leftImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_leftImg1_2.frameNStart = frameN  # exact frame index
        instructRight_leftImg1_2.tStart = t  # local t and not account for scr refresh
        instructRight_leftImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_leftImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructRight_leftImg1_2.setAutoDraw(True)
    
    # *instructRight_leftImg2_2* updates
    if instructRight_leftImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructRight_leftImg2_2.frameNStart = frameN  # exact frame index
        instructRight_leftImg2_2.tStart = t  # local t and not account for scr refresh
        instructRight_leftImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructRight_leftImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructRight_leftImg2_2.setAutoDraw(True)
    
    # *insructRight_keyResp_2* updates
    waitOnFlip = False
    if insructRight_keyResp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        insructRight_keyResp_2.frameNStart = frameN  # exact frame index
        insructRight_keyResp_2.tStart = t  # local t and not account for scr refresh
        insructRight_keyResp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(insructRight_keyResp_2, 'tStartRefresh')  # time at next scr refresh
        insructRight_keyResp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(insructRight_keyResp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(insructRight_keyResp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if insructRight_keyResp_2.status == STARTED and not waitOnFlip:
        theseKeys = insructRight_keyResp_2.getKeys(keyList=['8'], waitRelease=False)
        _insructRight_keyResp_2_allKeys.extend(theseKeys)
        if len(_insructRight_keyResp_2_allKeys):
            insructRight_keyResp_2.keys = _insructRight_keyResp_2_allKeys[-1].name  # just the last key pressed
            insructRight_keyResp_2.rt = _insructRight_keyResp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructRight_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructRight_2" ---
for thisComponent in instructRight_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructRight_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructLeft" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instructLeft_keyResp.keys = []
instructLeft_keyResp.rt = []
_instructLeft_keyResp_allKeys = []
# keep track of which components have finished
instructLeftComponents = [instructLeft_text, instructLeft_centerImg, instructLeft_rightImg1, instructLeft_rightImg2, instructLeft_leftImg1, instructLeft_leftImg2, instructLeft_keyResp]
for thisComponent in instructLeftComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructLeft" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructLeft_text* updates
    if instructLeft_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_text.frameNStart = frameN  # exact frame index
        instructLeft_text.tStart = t  # local t and not account for scr refresh
        instructLeft_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_text, 'tStartRefresh')  # time at next scr refresh
        instructLeft_text.setAutoDraw(True)
    
    # *instructLeft_centerImg* updates
    if instructLeft_centerImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_centerImg.frameNStart = frameN  # exact frame index
        instructLeft_centerImg.tStart = t  # local t and not account for scr refresh
        instructLeft_centerImg.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_centerImg, 'tStartRefresh')  # time at next scr refresh
        instructLeft_centerImg.setAutoDraw(True)
    
    # *instructLeft_rightImg1* updates
    if instructLeft_rightImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_rightImg1.frameNStart = frameN  # exact frame index
        instructLeft_rightImg1.tStart = t  # local t and not account for scr refresh
        instructLeft_rightImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_rightImg1, 'tStartRefresh')  # time at next scr refresh
        instructLeft_rightImg1.setAutoDraw(True)
    
    # *instructLeft_rightImg2* updates
    if instructLeft_rightImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_rightImg2.frameNStart = frameN  # exact frame index
        instructLeft_rightImg2.tStart = t  # local t and not account for scr refresh
        instructLeft_rightImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_rightImg2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_rightImg2.setAutoDraw(True)
    
    # *instructLeft_leftImg1* updates
    if instructLeft_leftImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_leftImg1.frameNStart = frameN  # exact frame index
        instructLeft_leftImg1.tStart = t  # local t and not account for scr refresh
        instructLeft_leftImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_leftImg1, 'tStartRefresh')  # time at next scr refresh
        instructLeft_leftImg1.setAutoDraw(True)
    
    # *instructLeft_leftImg2* updates
    if instructLeft_leftImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_leftImg2.frameNStart = frameN  # exact frame index
        instructLeft_leftImg2.tStart = t  # local t and not account for scr refresh
        instructLeft_leftImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_leftImg2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_leftImg2.setAutoDraw(True)
    
    # *instructLeft_keyResp* updates
    waitOnFlip = False
    if instructLeft_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_keyResp.frameNStart = frameN  # exact frame index
        instructLeft_keyResp.tStart = t  # local t and not account for scr refresh
        instructLeft_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_keyResp, 'tStartRefresh')  # time at next scr refresh
        instructLeft_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructLeft_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructLeft_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructLeft_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = instructLeft_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _instructLeft_keyResp_allKeys.extend(theseKeys)
        if len(_instructLeft_keyResp_allKeys):
            instructLeft_keyResp.keys = _instructLeft_keyResp_allKeys[-1].name  # just the last key pressed
            instructLeft_keyResp.rt = _instructLeft_keyResp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructLeftComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructLeft" ---
for thisComponent in instructLeftComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructLeft" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructLeft_2" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instructLeft_keyResp_2.keys = []
instructLeft_keyResp_2.rt = []
_instructLeft_keyResp_2_allKeys = []
# keep track of which components have finished
instructLeft_2Components = [instructLeft_text_2, instructLeft_centerImg_2, instructLeft_rightImg1_2, instructLeft_rightImg2_2, instructLeft_leftImg1_2, instructLeft_leftImg2_2, instructLeft_keyResp_2]
for thisComponent in instructLeft_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructLeft_2" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructLeft_text_2* updates
    if instructLeft_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_text_2.frameNStart = frameN  # exact frame index
        instructLeft_text_2.tStart = t  # local t and not account for scr refresh
        instructLeft_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_text_2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_text_2.setAutoDraw(True)
    
    # *instructLeft_centerImg_2* updates
    if instructLeft_centerImg_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_centerImg_2.frameNStart = frameN  # exact frame index
        instructLeft_centerImg_2.tStart = t  # local t and not account for scr refresh
        instructLeft_centerImg_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_centerImg_2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_centerImg_2.setAutoDraw(True)
    
    # *instructLeft_rightImg1_2* updates
    if instructLeft_rightImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_rightImg1_2.frameNStart = frameN  # exact frame index
        instructLeft_rightImg1_2.tStart = t  # local t and not account for scr refresh
        instructLeft_rightImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_rightImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_rightImg1_2.setAutoDraw(True)
    
    # *instructLeft_rightImg2_2* updates
    if instructLeft_rightImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_rightImg2_2.frameNStart = frameN  # exact frame index
        instructLeft_rightImg2_2.tStart = t  # local t and not account for scr refresh
        instructLeft_rightImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_rightImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_rightImg2_2.setAutoDraw(True)
    
    # *instructLeft_leftImg1_2* updates
    if instructLeft_leftImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_leftImg1_2.frameNStart = frameN  # exact frame index
        instructLeft_leftImg1_2.tStart = t  # local t and not account for scr refresh
        instructLeft_leftImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_leftImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_leftImg1_2.setAutoDraw(True)
    
    # *instructLeft_leftImg2_2* updates
    if instructLeft_leftImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_leftImg2_2.frameNStart = frameN  # exact frame index
        instructLeft_leftImg2_2.tStart = t  # local t and not account for scr refresh
        instructLeft_leftImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_leftImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_leftImg2_2.setAutoDraw(True)
    
    # *instructLeft_keyResp_2* updates
    waitOnFlip = False
    if instructLeft_keyResp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructLeft_keyResp_2.frameNStart = frameN  # exact frame index
        instructLeft_keyResp_2.tStart = t  # local t and not account for scr refresh
        instructLeft_keyResp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructLeft_keyResp_2, 'tStartRefresh')  # time at next scr refresh
        instructLeft_keyResp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructLeft_keyResp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructLeft_keyResp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructLeft_keyResp_2.status == STARTED and not waitOnFlip:
        theseKeys = instructLeft_keyResp_2.getKeys(keyList=['1'], waitRelease=False)
        _instructLeft_keyResp_2_allKeys.extend(theseKeys)
        if len(_instructLeft_keyResp_2_allKeys):
            instructLeft_keyResp_2.keys = _instructLeft_keyResp_2_allKeys[-1].name  # just the last key pressed
            instructLeft_keyResp_2.rt = _instructLeft_keyResp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructLeft_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructLeft_2" ---
for thisComponent in instructLeft_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructLeft_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructInconRight" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
insructInconRight_keyResp.keys = []
insructInconRight_keyResp.rt = []
_insructInconRight_keyResp_allKeys = []
# keep track of which components have finished
instructInconRightComponents = [instructInconRight_text, instructIncon_centerImg, instructIncon_rightImg1, instructIncon_rightImg2, instructIncon_leftImg1, instructInconRight_leftImg2, insructInconRight_keyResp]
for thisComponent in instructInconRightComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructInconRight" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructInconRight_text* updates
    if instructInconRight_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconRight_text.frameNStart = frameN  # exact frame index
        instructInconRight_text.tStart = t  # local t and not account for scr refresh
        instructInconRight_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconRight_text, 'tStartRefresh')  # time at next scr refresh
        instructInconRight_text.setAutoDraw(True)
    
    # *instructIncon_centerImg* updates
    if instructIncon_centerImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_centerImg.frameNStart = frameN  # exact frame index
        instructIncon_centerImg.tStart = t  # local t and not account for scr refresh
        instructIncon_centerImg.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_centerImg, 'tStartRefresh')  # time at next scr refresh
        instructIncon_centerImg.setAutoDraw(True)
    
    # *instructIncon_rightImg1* updates
    if instructIncon_rightImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_rightImg1.frameNStart = frameN  # exact frame index
        instructIncon_rightImg1.tStart = t  # local t and not account for scr refresh
        instructIncon_rightImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_rightImg1, 'tStartRefresh')  # time at next scr refresh
        instructIncon_rightImg1.setAutoDraw(True)
    
    # *instructIncon_rightImg2* updates
    if instructIncon_rightImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_rightImg2.frameNStart = frameN  # exact frame index
        instructIncon_rightImg2.tStart = t  # local t and not account for scr refresh
        instructIncon_rightImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_rightImg2, 'tStartRefresh')  # time at next scr refresh
        instructIncon_rightImg2.setAutoDraw(True)
    
    # *instructIncon_leftImg1* updates
    if instructIncon_leftImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_leftImg1.frameNStart = frameN  # exact frame index
        instructIncon_leftImg1.tStart = t  # local t and not account for scr refresh
        instructIncon_leftImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_leftImg1, 'tStartRefresh')  # time at next scr refresh
        instructIncon_leftImg1.setAutoDraw(True)
    
    # *instructInconRight_leftImg2* updates
    if instructInconRight_leftImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconRight_leftImg2.frameNStart = frameN  # exact frame index
        instructInconRight_leftImg2.tStart = t  # local t and not account for scr refresh
        instructInconRight_leftImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconRight_leftImg2, 'tStartRefresh')  # time at next scr refresh
        instructInconRight_leftImg2.setAutoDraw(True)
    
    # *insructInconRight_keyResp* updates
    waitOnFlip = False
    if insructInconRight_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        insructInconRight_keyResp.frameNStart = frameN  # exact frame index
        insructInconRight_keyResp.tStart = t  # local t and not account for scr refresh
        insructInconRight_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(insructInconRight_keyResp, 'tStartRefresh')  # time at next scr refresh
        insructInconRight_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(insructInconRight_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(insructInconRight_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if insructInconRight_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = insructInconRight_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _insructInconRight_keyResp_allKeys.extend(theseKeys)
        if len(_insructInconRight_keyResp_allKeys):
            insructInconRight_keyResp.keys = _insructInconRight_keyResp_allKeys[-1].name  # just the last key pressed
            insructInconRight_keyResp.rt = _insructInconRight_keyResp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructInconRightComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructInconRight" ---
for thisComponent in instructInconRightComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructInconRight" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructInconRight_2" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
insructInconRight_keyResp_2.keys = []
insructInconRight_keyResp_2.rt = []
_insructInconRight_keyResp_2_allKeys = []
# keep track of which components have finished
instructInconRight_2Components = [instructInconRight_text_2, instructIncon_centerImg_2, instructIncon_rightImg1_2, instructIncon_rightImg2_2, instructIncon_leftImg1_2, instructInconRight_leftImg2_2, insructInconRight_keyResp_2]
for thisComponent in instructInconRight_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructInconRight_2" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructInconRight_text_2* updates
    if instructInconRight_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconRight_text_2.frameNStart = frameN  # exact frame index
        instructInconRight_text_2.tStart = t  # local t and not account for scr refresh
        instructInconRight_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconRight_text_2, 'tStartRefresh')  # time at next scr refresh
        instructInconRight_text_2.setAutoDraw(True)
    
    # *instructIncon_centerImg_2* updates
    if instructIncon_centerImg_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_centerImg_2.frameNStart = frameN  # exact frame index
        instructIncon_centerImg_2.tStart = t  # local t and not account for scr refresh
        instructIncon_centerImg_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_centerImg_2, 'tStartRefresh')  # time at next scr refresh
        instructIncon_centerImg_2.setAutoDraw(True)
    
    # *instructIncon_rightImg1_2* updates
    if instructIncon_rightImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_rightImg1_2.frameNStart = frameN  # exact frame index
        instructIncon_rightImg1_2.tStart = t  # local t and not account for scr refresh
        instructIncon_rightImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_rightImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructIncon_rightImg1_2.setAutoDraw(True)
    
    # *instructIncon_rightImg2_2* updates
    if instructIncon_rightImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_rightImg2_2.frameNStart = frameN  # exact frame index
        instructIncon_rightImg2_2.tStart = t  # local t and not account for scr refresh
        instructIncon_rightImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_rightImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructIncon_rightImg2_2.setAutoDraw(True)
    
    # *instructIncon_leftImg1_2* updates
    if instructIncon_leftImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructIncon_leftImg1_2.frameNStart = frameN  # exact frame index
        instructIncon_leftImg1_2.tStart = t  # local t and not account for scr refresh
        instructIncon_leftImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructIncon_leftImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructIncon_leftImg1_2.setAutoDraw(True)
    
    # *instructInconRight_leftImg2_2* updates
    if instructInconRight_leftImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconRight_leftImg2_2.frameNStart = frameN  # exact frame index
        instructInconRight_leftImg2_2.tStart = t  # local t and not account for scr refresh
        instructInconRight_leftImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconRight_leftImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructInconRight_leftImg2_2.setAutoDraw(True)
    
    # *insructInconRight_keyResp_2* updates
    waitOnFlip = False
    if insructInconRight_keyResp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        insructInconRight_keyResp_2.frameNStart = frameN  # exact frame index
        insructInconRight_keyResp_2.tStart = t  # local t and not account for scr refresh
        insructInconRight_keyResp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(insructInconRight_keyResp_2, 'tStartRefresh')  # time at next scr refresh
        insructInconRight_keyResp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(insructInconRight_keyResp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(insructInconRight_keyResp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if insructInconRight_keyResp_2.status == STARTED and not waitOnFlip:
        theseKeys = insructInconRight_keyResp_2.getKeys(keyList=['8'], waitRelease=False)
        _insructInconRight_keyResp_2_allKeys.extend(theseKeys)
        if len(_insructInconRight_keyResp_2_allKeys):
            insructInconRight_keyResp_2.keys = _insructInconRight_keyResp_2_allKeys[-1].name  # just the last key pressed
            insructInconRight_keyResp_2.rt = _insructInconRight_keyResp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructInconRight_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructInconRight_2" ---
for thisComponent in instructInconRight_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructInconRight_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructInconLeft" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instructInconLeft_keyResp.keys = []
instructInconLeft_keyResp.rt = []
_instructInconLeft_keyResp_allKeys = []
# keep track of which components have finished
instructInconLeftComponents = [instructInconLeft_text, instructInconLeft_centerImg, instructInconLeft_rightImg1, instructInconLeft_rightImg2, instructInconLeft_leftImg1, instructInconLeft_leftImg2, instructInconLeft_keyResp]
for thisComponent in instructInconLeftComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructInconLeft" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructInconLeft_text* updates
    if instructInconLeft_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_text.frameNStart = frameN  # exact frame index
        instructInconLeft_text.tStart = t  # local t and not account for scr refresh
        instructInconLeft_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_text, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_text.setAutoDraw(True)
    
    # *instructInconLeft_centerImg* updates
    if instructInconLeft_centerImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_centerImg.frameNStart = frameN  # exact frame index
        instructInconLeft_centerImg.tStart = t  # local t and not account for scr refresh
        instructInconLeft_centerImg.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_centerImg, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_centerImg.setAutoDraw(True)
    
    # *instructInconLeft_rightImg1* updates
    if instructInconLeft_rightImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_rightImg1.frameNStart = frameN  # exact frame index
        instructInconLeft_rightImg1.tStart = t  # local t and not account for scr refresh
        instructInconLeft_rightImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_rightImg1, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_rightImg1.setAutoDraw(True)
    
    # *instructInconLeft_rightImg2* updates
    if instructInconLeft_rightImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_rightImg2.frameNStart = frameN  # exact frame index
        instructInconLeft_rightImg2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_rightImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_rightImg2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_rightImg2.setAutoDraw(True)
    
    # *instructInconLeft_leftImg1* updates
    if instructInconLeft_leftImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_leftImg1.frameNStart = frameN  # exact frame index
        instructInconLeft_leftImg1.tStart = t  # local t and not account for scr refresh
        instructInconLeft_leftImg1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_leftImg1, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_leftImg1.setAutoDraw(True)
    
    # *instructInconLeft_leftImg2* updates
    if instructInconLeft_leftImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_leftImg2.frameNStart = frameN  # exact frame index
        instructInconLeft_leftImg2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_leftImg2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_leftImg2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_leftImg2.setAutoDraw(True)
    
    # *instructInconLeft_keyResp* updates
    waitOnFlip = False
    if instructInconLeft_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_keyResp.frameNStart = frameN  # exact frame index
        instructInconLeft_keyResp.tStart = t  # local t and not account for scr refresh
        instructInconLeft_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_keyResp, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_keyResp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructInconLeft_keyResp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructInconLeft_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructInconLeft_keyResp.status == STARTED and not waitOnFlip:
        theseKeys = instructInconLeft_keyResp.getKeys(keyList=['c'], waitRelease=False)
        _instructInconLeft_keyResp_allKeys.extend(theseKeys)
        if len(_instructInconLeft_keyResp_allKeys):
            instructInconLeft_keyResp.keys = _instructInconLeft_keyResp_allKeys[-1].name  # just the last key pressed
            instructInconLeft_keyResp.rt = _instructInconLeft_keyResp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructInconLeftComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructInconLeft" ---
for thisComponent in instructInconLeftComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructInconLeft" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructInconLeft_2" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instructInconLeft_keyResp_2.keys = []
instructInconLeft_keyResp_2.rt = []
_instructInconLeft_keyResp_2_allKeys = []
# keep track of which components have finished
instructInconLeft_2Components = [instructInconLeft_text_2, instructInconLeft_centerImg_2, instructInconLeft_rightImg1_2, instructInconLeft_rightImg2_2, instructInconLeft_leftImg1_2, instructInconLeft_leftImg2_2, instructInconLeft_keyResp_2]
for thisComponent in instructInconLeft_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructInconLeft_2" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instructInconLeft_text_2* updates
    if instructInconLeft_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_text_2.frameNStart = frameN  # exact frame index
        instructInconLeft_text_2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_text_2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_text_2.setAutoDraw(True)
    
    # *instructInconLeft_centerImg_2* updates
    if instructInconLeft_centerImg_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_centerImg_2.frameNStart = frameN  # exact frame index
        instructInconLeft_centerImg_2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_centerImg_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_centerImg_2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_centerImg_2.setAutoDraw(True)
    
    # *instructInconLeft_rightImg1_2* updates
    if instructInconLeft_rightImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_rightImg1_2.frameNStart = frameN  # exact frame index
        instructInconLeft_rightImg1_2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_rightImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_rightImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_rightImg1_2.setAutoDraw(True)
    
    # *instructInconLeft_rightImg2_2* updates
    if instructInconLeft_rightImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_rightImg2_2.frameNStart = frameN  # exact frame index
        instructInconLeft_rightImg2_2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_rightImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_rightImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_rightImg2_2.setAutoDraw(True)
    
    # *instructInconLeft_leftImg1_2* updates
    if instructInconLeft_leftImg1_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_leftImg1_2.frameNStart = frameN  # exact frame index
        instructInconLeft_leftImg1_2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_leftImg1_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_leftImg1_2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_leftImg1_2.setAutoDraw(True)
    
    # *instructInconLeft_leftImg2_2* updates
    if instructInconLeft_leftImg2_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_leftImg2_2.frameNStart = frameN  # exact frame index
        instructInconLeft_leftImg2_2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_leftImg2_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_leftImg2_2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_leftImg2_2.setAutoDraw(True)
    
    # *instructInconLeft_keyResp_2* updates
    waitOnFlip = False
    if instructInconLeft_keyResp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instructInconLeft_keyResp_2.frameNStart = frameN  # exact frame index
        instructInconLeft_keyResp_2.tStart = t  # local t and not account for scr refresh
        instructInconLeft_keyResp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instructInconLeft_keyResp_2, 'tStartRefresh')  # time at next scr refresh
        instructInconLeft_keyResp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instructInconLeft_keyResp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instructInconLeft_keyResp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instructInconLeft_keyResp_2.status == STARTED and not waitOnFlip:
        theseKeys = instructInconLeft_keyResp_2.getKeys(keyList=['1'], waitRelease=False)
        _instructInconLeft_keyResp_2_allKeys.extend(theseKeys)
        if len(_instructInconLeft_keyResp_2_allKeys):
            instructInconLeft_keyResp_2.keys = _instructInconLeft_keyResp_2_allKeys[-1].name  # just the last key pressed
            instructInconLeft_keyResp_2.rt = _instructInconLeft_keyResp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructInconLeft_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructInconLeft_2" ---
for thisComponent in instructInconLeft_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "instructInconLeft_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "respond_onceInstruct" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
respond_once_key_resp1.keys = []
respond_once_key_resp1.rt = []
_respond_once_key_resp1_allKeys = []
# keep track of which components have finished
respond_onceInstructComponents = [respond_once_text, respond_once_key_resp1]
for thisComponent in respond_onceInstructComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "respond_onceInstruct" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *respond_once_text* updates
    if respond_once_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        respond_once_text.frameNStart = frameN  # exact frame index
        respond_once_text.tStart = t  # local t and not account for scr refresh
        respond_once_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(respond_once_text, 'tStartRefresh')  # time at next scr refresh
        respond_once_text.setAutoDraw(True)
    
    # *respond_once_key_resp1* updates
    waitOnFlip = False
    if respond_once_key_resp1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        respond_once_key_resp1.frameNStart = frameN  # exact frame index
        respond_once_key_resp1.tStart = t  # local t and not account for scr refresh
        respond_once_key_resp1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(respond_once_key_resp1, 'tStartRefresh')  # time at next scr refresh
        respond_once_key_resp1.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(respond_once_key_resp1.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(respond_once_key_resp1.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if respond_once_key_resp1.status == STARTED and not waitOnFlip:
        theseKeys = respond_once_key_resp1.getKeys(keyList=['c'], waitRelease=False)
        _respond_once_key_resp1_allKeys.extend(theseKeys)
        if len(_respond_once_key_resp1_allKeys):
            respond_once_key_resp1.keys = _respond_once_key_resp1_allKeys[-1].name  # just the last key pressed
            respond_once_key_resp1.rt = _respond_once_key_resp1_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in respond_onceInstructComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "respond_onceInstruct" ---
for thisComponent in respond_onceInstructComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "respond_onceInstruct" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
prac_block_loop = data.TrialHandler(nReps=999, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('blockSelect_practice.csv'),
    seed=None, name='prac_block_loop')
thisExp.addLoop(prac_block_loop)  # add the loop to the experiment
thisPrac_block_loop = prac_block_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPrac_block_loop.rgb)
if thisPrac_block_loop != None:
    for paramName in thisPrac_block_loop:
        exec('{} = thisPrac_block_loop[paramName]'.format(paramName))

for thisPrac_block_loop in prac_block_loop:
    currentLoop = prac_block_loop
    # abbreviate parameter names if possible (e.g. rgb = thisPrac_block_loop.rgb)
    if thisPrac_block_loop != None:
        for paramName in thisPrac_block_loop:
            exec('{} = thisPrac_block_loop[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "eeg_trigger_check" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from triggerCheck_code
    #(re)open trigger port. This is done in case the connection failed,
    #in which case triggers will no longer be sent until the port is reopened.
    
    #At start of routine, we try to close/open the port. This will usually be
    #succesful, causing us to end the routine altogether. However, it will fail if 
    #the usb is unplugged. In this latter case, the routine will then run code each
    #frame to constantly check for the usb being plugged back in, before continuing.
    
    try: 
    #if usb connected, port will close/open and routine will end
        port.close()
        port.open()
        usbConnected = 1 #if successful, set usbConnectd to 1
        continueRoutine = False #if successful, end the routine
    
    except: #if port close/open fails, then set usbConnected to 0. Routine will loop each frame until fixed.
        usbConnected = 0 #if failure, set usbConnected to 0
    # keep track of which components have finished
    eeg_trigger_checkComponents = [triggerIssue_text]
    for thisComponent in eeg_trigger_checkComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "eeg_trigger_check" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from triggerCheck_code
        #if the usb is not connected, then keep trying to open port to determine when it has been reconnected.
        if usbConnected == 0:
            
            try: 
                #if usb connected, port will close/open and routine will end
                port.close()
                port.open()
                usbConnected = 1 #if successful, set usbConnectd to 1
                #send trigger to indicate that there was a connection issue that is now resolved
                port.write([0x63]) #hexcode = 99; eeg trigger sent
                time.sleep(PulseWidth) #how long to wait before clearing trigger port
                port.write([0x00]) #clear trigger port by sending hexcode = 0
                #if successful, end the routine
                continueRoutine = False
            
            except: #if usb not connected, routine will continue (keep checking port and keep showing message)
                usbConnected = 0 #if failure, set usbConnectd to 0
                time.sleep(0.5) #wait .5 secs before checking again, to not overload the system
        
        # *triggerIssue_text* updates
        if triggerIssue_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            triggerIssue_text.frameNStart = frameN  # exact frame index
            triggerIssue_text.tStart = t  # local t and not account for scr refresh
            triggerIssue_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(triggerIssue_text, 'tStartRefresh')  # time at next scr refresh
            triggerIssue_text.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in eeg_trigger_checkComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "eeg_trigger_check" ---
    for thisComponent in eeg_trigger_checkComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "eeg_trigger_check" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "prac_blockReminders" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    prac_reminder_keyResp.keys = []
    prac_reminder_keyResp.rt = []
    _prac_reminder_keyResp_allKeys = []
    # keep track of which components have finished
    prac_blockRemindersComponents = [prac_blockText, prac_reminder_text, prac_reminder_keyResp]
    for thisComponent in prac_blockRemindersComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "prac_blockReminders" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *prac_blockText* updates
        if prac_blockText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_blockText.frameNStart = frameN  # exact frame index
            prac_blockText.tStart = t  # local t and not account for scr refresh
            prac_blockText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_blockText, 'tStartRefresh')  # time at next scr refresh
            prac_blockText.setAutoDraw(True)
        
        # *prac_reminder_text* updates
        if prac_reminder_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_reminder_text.frameNStart = frameN  # exact frame index
            prac_reminder_text.tStart = t  # local t and not account for scr refresh
            prac_reminder_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_reminder_text, 'tStartRefresh')  # time at next scr refresh
            prac_reminder_text.setAutoDraw(True)
        
        # *prac_reminder_keyResp* updates
        waitOnFlip = False
        if prac_reminder_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_reminder_keyResp.frameNStart = frameN  # exact frame index
            prac_reminder_keyResp.tStart = t  # local t and not account for scr refresh
            prac_reminder_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_reminder_keyResp, 'tStartRefresh')  # time at next scr refresh
            prac_reminder_keyResp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(prac_reminder_keyResp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(prac_reminder_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if prac_reminder_keyResp.status == STARTED and not waitOnFlip:
            theseKeys = prac_reminder_keyResp.getKeys(keyList=['c'], waitRelease=False)
            _prac_reminder_keyResp_allKeys.extend(theseKeys)
            if len(_prac_reminder_keyResp_allKeys):
                prac_reminder_keyResp.keys = _prac_reminder_keyResp_allKeys[-1].name  # just the last key pressed
                prac_reminder_keyResp.rt = _prac_reminder_keyResp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in prac_blockRemindersComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "prac_blockReminders" ---
    for thisComponent in prac_blockRemindersComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "prac_blockReminders" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "prac_blockReminders_2" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    prac_reminder_keyResp_2.keys = []
    prac_reminder_keyResp_2.rt = []
    _prac_reminder_keyResp_2_allKeys = []
    # keep track of which components have finished
    prac_blockReminders_2Components = [prac_blockText_2, prac_reminder_text_2, prac_reminder_keyResp_2]
    for thisComponent in prac_blockReminders_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "prac_blockReminders_2" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *prac_blockText_2* updates
        if prac_blockText_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_blockText_2.frameNStart = frameN  # exact frame index
            prac_blockText_2.tStart = t  # local t and not account for scr refresh
            prac_blockText_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_blockText_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'prac_blockText_2.started')
            prac_blockText_2.setAutoDraw(True)
        
        # *prac_reminder_text_2* updates
        if prac_reminder_text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_reminder_text_2.frameNStart = frameN  # exact frame index
            prac_reminder_text_2.tStart = t  # local t and not account for scr refresh
            prac_reminder_text_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_reminder_text_2, 'tStartRefresh')  # time at next scr refresh
            prac_reminder_text_2.setAutoDraw(True)
        
        # *prac_reminder_keyResp_2* updates
        waitOnFlip = False
        if prac_reminder_keyResp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_reminder_keyResp_2.frameNStart = frameN  # exact frame index
            prac_reminder_keyResp_2.tStart = t  # local t and not account for scr refresh
            prac_reminder_keyResp_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_reminder_keyResp_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'prac_reminder_keyResp_2.started')
            prac_reminder_keyResp_2.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(prac_reminder_keyResp_2.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(prac_reminder_keyResp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if prac_reminder_keyResp_2.status == STARTED and not waitOnFlip:
            theseKeys = prac_reminder_keyResp_2.getKeys(keyList=['8'], waitRelease=False)
            _prac_reminder_keyResp_2_allKeys.extend(theseKeys)
            if len(_prac_reminder_keyResp_2_allKeys):
                prac_reminder_keyResp_2.keys = _prac_reminder_keyResp_2_allKeys[-1].name  # just the last key pressed
                prac_reminder_keyResp_2.rt = _prac_reminder_keyResp_2_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in prac_blockReminders_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "prac_blockReminders_2" ---
    for thisComponent in prac_blockReminders_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "prac_blockReminders_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "initFixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    initFixation_img.setImage('img/transp_fixation.png')
    # keep track of which components have finished
    initFixationComponents = [initFixation_img]
    for thisComponent in initFixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "initFixation" ---
    while continueRoutine and routineTimer.getTime() < 2.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *initFixation_img* updates
        if initFixation_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            initFixation_img.frameNStart = frameN  # exact frame index
            initFixation_img.tStart = t  # local t and not account for scr refresh
            initFixation_img.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(initFixation_img, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'initFixation_img.started')
            initFixation_img.setAutoDraw(True)
        if initFixation_img.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > initFixation_img.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                initFixation_img.tStop = t  # not accounting for scr refresh
                initFixation_img.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'initFixation_img.stopped')
                initFixation_img.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in initFixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "initFixation" ---
    for thisComponent in initFixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-2.000000)
    
    # set up handler to look after randomisation of conditions etc
    prac_trial_loop = data.TrialHandler(nReps=1, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(whichBlock),
        seed=None, name='prac_trial_loop')
    thisExp.addLoop(prac_trial_loop)  # add the loop to the experiment
    thisPrac_trial_loop = prac_trial_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisPrac_trial_loop.rgb)
    if thisPrac_trial_loop != None:
        for paramName in thisPrac_trial_loop:
            exec('{} = thisPrac_trial_loop[paramName]'.format(paramName))
    
    for thisPrac_trial_loop in prac_trial_loop:
        currentLoop = prac_trial_loop
        # abbreviate parameter names if possible (e.g. rgb = thisPrac_trial_loop.rgb)
        if thisPrac_trial_loop != None:
            for paramName in thisPrac_trial_loop:
                exec('{} = thisPrac_trial_loop[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "prac_stimRoutine" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # Run 'Begin Routine' code from prac_isi_code
        # pick the ISI for the next routine
        # this code component is set to 'both' because we need to remove the 'np'
        # at the start of np.linspace (this is a python library JS won't know what to call. 
        
        # make range from a to b in n stepsizes
        ISIRange = np.linspace(3500, 4000, 500)
        
        # picking from a shuffled array is easier for random selection in JS
        shuffle(ISIRange)
        thisISI = ISIRange[0]/1000 # the first item of the shuffled array 
        
        # save this ISI to our output file
        prac_trial_loop.addData('ISI', thisISI)
        
        
        # show in console for debugging
        #print('thisISI: ', thisISI)
        prac_background_face.setImage(straightFace)
        # Run 'Begin Routine' code from prac_face_trigger_code
        #set stimTriggerSent to false at the start of the trial. this way
        #when the stimulus is shown, we can change it to True. This variable
        #is used to ensure we only throw the stimulus EEG trigger once.
        stimTriggerSentZ1 = False
        prac_cover_background.setImage('img/cover_background.png')
        prac_centerImg.setPos((0, 0))
        prac_centerImg.setSize([0.48, 0.48])
        prac_centerImg.setImage(middleStim)
        prac_rightImg1.setPos((0.567, 0))
        prac_rightImg1.setSize([0.48, 0.48])
        prac_rightImg1.setImage(rightStim)
        prac_rightImg2.setPos([1.135, 0])
        prac_rightImg2.setSize([0.48, 0.48])
        prac_rightImg2.setImage(rightStim)
        prac_leftImg1.setPos((-0.567, 0))
        prac_leftImg1.setSize([0.48, 0.48])
        prac_leftImg1.setImage(leftStim)
        prac_leftImg2.setPos((-1.135, 0))
        prac_leftImg2.setSize([0.48, 0.48])
        prac_leftImg2.setImage(leftStim)
        prac_fixImg.setImage('img/transp_fixation.png')
        # Run 'Begin Routine' code from prac_stimTrigger_code
        #set stimTriggerSent to false at the start of the trial. this way
        #when the stimulus is shown, we can change it to True. This variable
        #is used to ensure we only throw the stimulus EEG trigger once.
        stimTriggerSent = False
        prac_stim_keyResp.keys = []
        prac_stim_keyResp.rt = []
        _prac_stim_keyResp_allKeys = []
        # Run 'Begin Routine' code from prac_respTrigger_code
        #clear out the keys_counbted variable at the start of the trial
        #this variable will hold the keys that have had eeg triggers thrown
        #already within a given trial.
        keys_counted = []
        # keep track of which components have finished
        prac_stimRoutineComponents = [prac_background_face, prac_cover_background, prac_centerImg, prac_rightImg1, prac_rightImg2, prac_leftImg1, prac_leftImg2, prac_fixImg, prac_stim_keyResp]
        for thisComponent in prac_stimRoutineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "prac_stimRoutine" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *prac_background_face* updates
            if prac_background_face.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_background_face.frameNStart = frameN  # exact frame index
                prac_background_face.tStart = t  # local t and not account for scr refresh
                prac_background_face.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_background_face, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_background_face.started')
                prac_background_face.setAutoDraw(True)
            if prac_background_face.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_background_face.tStartRefresh + thisISI-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_background_face.tStop = t  # not accounting for scr refresh
                    prac_background_face.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'prac_background_face.stopped')
                    prac_background_face.setAutoDraw(False)
            # Run 'Each Frame' code from prac_face_trigger_code
            #the first if statement below ensures that the subsequent if statements (and throwing of triggers)
            #only occurs once per trial. That is, only when the stimulus is presented (.status = STARTED) and
            #stimTriggerSent is still False. Once a trigger is sent, we change stimTriggerSentZ1 to True so that 
            #the stimulus eeg trigger will not be sent again for this trial
            if prac_background_face.status == STARTED and not stimTriggerSentZ1:
                stimTriggerSentZ1 = True #switch stimTriggerSentZ1 to True so that the stimulus eeg trigger will not be sent again this trial
                port.write([0x09]) #hexcode = 9; eeg trigger sent
                time.sleep(PulseWidth) #how long to wait before clearing trigger port
                port.write([0x00]) #clear trigger port by sending hexcode = 0
            
            
            # *prac_cover_background* updates
            if prac_cover_background.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_cover_background.frameNStart = frameN  # exact frame index
                prac_cover_background.tStart = t  # local t and not account for scr refresh
                prac_cover_background.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_cover_background, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_cover_background.started')
                prac_cover_background.setAutoDraw(True)
            if prac_cover_background.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_cover_background.tStartRefresh + 0.35-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_cover_background.tStop = t  # not accounting for scr refresh
                    prac_cover_background.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'prac_cover_background.stopped')
                    prac_cover_background.setAutoDraw(False)
            
            # *prac_centerImg* updates
            if prac_centerImg.status == NOT_STARTED and tThisFlip >= 0.15-frameTolerance:
                # keep track of start time/frame for later
                prac_centerImg.frameNStart = frameN  # exact frame index
                prac_centerImg.tStart = t  # local t and not account for scr refresh
                prac_centerImg.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_centerImg, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_centerImg.started')
                prac_centerImg.setAutoDraw(True)
            if prac_centerImg.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_centerImg.tStartRefresh + .2-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_centerImg.tStop = t  # not accounting for scr refresh
                    prac_centerImg.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'prac_centerImg.stopped')
                    prac_centerImg.setAutoDraw(False)
            
            # *prac_rightImg1* updates
            if prac_rightImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_rightImg1.frameNStart = frameN  # exact frame index
                prac_rightImg1.tStart = t  # local t and not account for scr refresh
                prac_rightImg1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_rightImg1, 'tStartRefresh')  # time at next scr refresh
                prac_rightImg1.setAutoDraw(True)
            if prac_rightImg1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_rightImg1.tStartRefresh + .350-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_rightImg1.tStop = t  # not accounting for scr refresh
                    prac_rightImg1.frameNStop = frameN  # exact frame index
                    prac_rightImg1.setAutoDraw(False)
            
            # *prac_rightImg2* updates
            if prac_rightImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_rightImg2.frameNStart = frameN  # exact frame index
                prac_rightImg2.tStart = t  # local t and not account for scr refresh
                prac_rightImg2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_rightImg2, 'tStartRefresh')  # time at next scr refresh
                prac_rightImg2.setAutoDraw(True)
            if prac_rightImg2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_rightImg2.tStartRefresh + .350-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_rightImg2.tStop = t  # not accounting for scr refresh
                    prac_rightImg2.frameNStop = frameN  # exact frame index
                    prac_rightImg2.setAutoDraw(False)
            
            # *prac_leftImg1* updates
            if prac_leftImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_leftImg1.frameNStart = frameN  # exact frame index
                prac_leftImg1.tStart = t  # local t and not account for scr refresh
                prac_leftImg1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_leftImg1, 'tStartRefresh')  # time at next scr refresh
                prac_leftImg1.setAutoDraw(True)
            if prac_leftImg1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_leftImg1.tStartRefresh + .350-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_leftImg1.tStop = t  # not accounting for scr refresh
                    prac_leftImg1.frameNStop = frameN  # exact frame index
                    prac_leftImg1.setAutoDraw(False)
            
            # *prac_leftImg2* updates
            if prac_leftImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_leftImg2.frameNStart = frameN  # exact frame index
                prac_leftImg2.tStart = t  # local t and not account for scr refresh
                prac_leftImg2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_leftImg2, 'tStartRefresh')  # time at next scr refresh
                prac_leftImg2.setAutoDraw(True)
            if prac_leftImg2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_leftImg2.tStartRefresh + .350-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_leftImg2.tStop = t  # not accounting for scr refresh
                    prac_leftImg2.frameNStop = frameN  # exact frame index
                    prac_leftImg2.setAutoDraw(False)
            
            # *prac_fixImg* updates
            if prac_fixImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_fixImg.frameNStart = frameN  # exact frame index
                prac_fixImg.tStart = t  # local t and not account for scr refresh
                prac_fixImg.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_fixImg, 'tStartRefresh')  # time at next scr refresh
                prac_fixImg.setAutoDraw(True)
            if prac_fixImg.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_fixImg.tStartRefresh + thisISI-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_fixImg.tStop = t  # not accounting for scr refresh
                    prac_fixImg.frameNStop = frameN  # exact frame index
                    prac_fixImg.setAutoDraw(False)
            # Run 'Each Frame' code from prac_stimTrigger_code
            #the first if statement below ensures that the subsequent if statements (and throwing of triggers)
            #only occurs once per trial. That is, only when the stimulus is presented (.status = STARTED) and
            #stimTriggerSent is still False. Once a trigger is sent, we change stimTriggerSent to True so that 
            #the stimulus eeg trigger will not be sent again for this trial
            if prac_centerImg.status == STARTED and not stimTriggerSent:
                if stimNum == 5: #code denoting which stimulus array was sent (from excel file)
                    stimTriggerSent = True #switch stimTriggerSent to True so that the stimulus eeg trigger will not be sent again this trial
                    port.write([0x01]) #hexcode = 1; eeg trigger sent
                    time.sleep(PulseWidth) #how long to wait before clearing trigger port
                    port.write([0x00]) #clear trigger port by sending hexcode = 0
                elif stimNum == 6:
                    stimTriggerSent = True
                    port.write([0x02]) #hexcode = 2;
                    time.sleep(PulseWidth)
                    port.write([0x00])
                elif stimNum == 7:
                    stimTriggerSent = True
                    port.write([0x03]) #hexcode = 3;
                    time.sleep(PulseWidth)
                    port.write([0x00])
                elif stimNum == 8:
                    stimTriggerSent = True
                    port.write([0x04]) #hexcode = 4;
                    time.sleep(PulseWidth)
                    port.write([0x00])
            
            # *prac_stim_keyResp* updates
            waitOnFlip = False
            if prac_stim_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                prac_stim_keyResp.frameNStart = frameN  # exact frame index
                prac_stim_keyResp.tStart = t  # local t and not account for scr refresh
                prac_stim_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(prac_stim_keyResp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'prac_stim_keyResp.started')
                prac_stim_keyResp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(prac_stim_keyResp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(prac_stim_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if prac_stim_keyResp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > prac_stim_keyResp.tStartRefresh + thisISI-frameTolerance:
                    # keep track of stop time/frame for later
                    prac_stim_keyResp.tStop = t  # not accounting for scr refresh
                    prac_stim_keyResp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'prac_stim_keyResp.stopped')
                    prac_stim_keyResp.status = FINISHED
            if prac_stim_keyResp.status == STARTED and not waitOnFlip:
                theseKeys = prac_stim_keyResp.getKeys(keyList=['1','8'], waitRelease=False)
                _prac_stim_keyResp_allKeys.extend(theseKeys)
                if len(_prac_stim_keyResp_allKeys):
                    prac_stim_keyResp.keys = [key.name for key in _prac_stim_keyResp_allKeys]  # storing all keys
                    prac_stim_keyResp.rt = [key.rt for key in _prac_stim_keyResp_allKeys]
            # Run 'Each Frame' code from prac_respTrigger_code
            if prac_stim_keyResp.keys and len(prac_stim_keyResp.keys) > len(keys_counted):# A key response has been made but we haven't yet "counted" it
                keys_counted.append(prac_stim_keyResp.keys[-1]) #add this response to list of keys pressed this trial
                if len(prac_stim_keyResp.keys) < 2: #if this is  the first response
                    if prac_stim_keyResp.keys[-1] == '1':
                        if target == 'left': #correct response
                            port.write([0x0B]) # 11
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'right': #error response
                            port.write([0x0C])# 12
                            time.sleep(PulseWidth)
                            port.write([0x00])
                    elif prac_stim_keyResp.keys[-1] == '8':
                        if target == 'right': #correct response
                            port.write([0x0B]) # 11
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'left': #error response
                            port.write([0x0C])# 12
                            time.sleep(PulseWidth)
                            port.write([0x00])
                elif len(prac_stim_keyResp.keys) >= 2: #if this is NOT the first response
                    if prac_stim_keyResp.keys[-1] == '1':
                        if target == 'left': #technically correct response, but not the first response made
                            port.write([0x15]) # 21
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'right': #technically error response, but not the first response made
                            port.write([0x16])# 22
                            time.sleep(PulseWidth)
                            port.write([0x00])
                    elif prac_stim_keyResp.keys[-1] == '8':
                        if target == 'right': #technically correct response, but not the first response made
                            port.write([0x15]) # 21
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'left': #technically error response, but not the first response made
                            port.write([0x16])# 22
                            time.sleep(PulseWidth)
                            port.write([0x00])
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in prac_stimRoutineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "prac_stimRoutine" ---
        for thisComponent in prac_stimRoutineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if prac_stim_keyResp.keys in ['', [], None]:  # No response was made
            prac_stim_keyResp.keys = None
        prac_trial_loop.addData('prac_stim_keyResp.keys',prac_stim_keyResp.keys)
        if prac_stim_keyResp.keys != None:  # we had a response
            prac_trial_loop.addData('prac_stim_keyResp.rt', prac_stim_keyResp.rt)
        # Run 'End Routine' code from prac_respTrigger_code
        
        #instead of including here, should instead include something
        #in each frame section that computes t at stim onset and then
        #when thisISI - t <= .05 (50 ms) and then at that point we throw
        #the no-resp marker...
        
        #if not prac_stim_keyResp.keys or len(prac_stim_keyResp.keys) == 0:
        #            port.write([0x63]) # 99
        #            time.sleep(PulseWidth)
        #            port.write([0x00])
        # Run 'End Routine' code from prac_accuracy_code
        trialNum = trialNum + 1 #iterate trial number for this block
        
        if prac_stim_keyResp.keys: #if at least one response was made this trial
            if prac_stim_keyResp.keys[0] == '1': #if the FIRST button pressed was a '1'
                if target == 'left': #if a left target stim was shown this trial
                    accuracy = 1 #mark this trial as correct
                    numCorr = numCorr +1 #iterate number of correct responses for this block
                elif target == 'right': #if a right target stim was shown this trial
                    accuracy = 0 #mark this trial as an error
            elif prac_stim_keyResp.keys[0] == '8': #if the FIRST button pressed was a '8'
                if target == 'right': #if a right target stim was shown this trial
                    accuracy = 1 #mark this trial as correct
                    numCorr = numCorr +1 #iterate number of correct responses for this block
                elif target == 'left': #if a left target stim was shown this trial
                    accuracy = 0 #mark this trial as an error
        
        elif not prac_stim_keyResp.keys: # if no response was made
            accuracy = 0
                    
        # save this trial's accuracy to our output file
        prac_trial_loop.addData('accuracy', accuracy)
        
        # the Routine "prac_stimRoutine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1 repeats of 'prac_trial_loop'
    
    
    # --- Prepare to start Routine "prac_blockFeed" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from prac_blockFeed_code
    blockAcc = numCorr / trialNum #compute accuracy for this block
    
    if blockAcc >= .75: #if accuracy >= 75% then say practice is complete and end practice loop to continue to main exp
        outPut = 'You will now play the real game' #feedback presented
        prac_block_loop.finished = True #end practice loop to continue to main exp
    elif blockAcc <= .75: #if accuracy < 75% then say that practice needs to be repeated and DO NOT end practice loop, instead, allow it to repeat
        outPut = 'Please try the practice again' #feedback presented
        prac_block_loop.finished = False #DO NOT end practice loop and allow to repeat
    
    #reset the following variables to zero before the next practice block starts
    trialNum = 0
    numCorr = 0
    prac_blockFeed_text.setText(outPut)
    prac_blockFeed_keyResp.keys = []
    prac_blockFeed_keyResp.rt = []
    _prac_blockFeed_keyResp_allKeys = []
    # keep track of which components have finished
    prac_blockFeedComponents = [prac_blockFeed_text, prac_pressContinue, prac_blockFeed_keyResp]
    for thisComponent in prac_blockFeedComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "prac_blockFeed" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *prac_blockFeed_text* updates
        if prac_blockFeed_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_blockFeed_text.frameNStart = frameN  # exact frame index
            prac_blockFeed_text.tStart = t  # local t and not account for scr refresh
            prac_blockFeed_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_blockFeed_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'prac_blockFeed_text.started')
            prac_blockFeed_text.setAutoDraw(True)
        
        # *prac_pressContinue* updates
        if prac_pressContinue.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_pressContinue.frameNStart = frameN  # exact frame index
            prac_pressContinue.tStart = t  # local t and not account for scr refresh
            prac_pressContinue.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_pressContinue, 'tStartRefresh')  # time at next scr refresh
            prac_pressContinue.setAutoDraw(True)
        
        # *prac_blockFeed_keyResp* updates
        waitOnFlip = False
        if prac_blockFeed_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            prac_blockFeed_keyResp.frameNStart = frameN  # exact frame index
            prac_blockFeed_keyResp.tStart = t  # local t and not account for scr refresh
            prac_blockFeed_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(prac_blockFeed_keyResp, 'tStartRefresh')  # time at next scr refresh
            prac_blockFeed_keyResp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(prac_blockFeed_keyResp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(prac_blockFeed_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if prac_blockFeed_keyResp.status == STARTED and not waitOnFlip:
            theseKeys = prac_blockFeed_keyResp.getKeys(keyList=['c','s'], waitRelease=False)
            _prac_blockFeed_keyResp_allKeys.extend(theseKeys)
            if len(_prac_blockFeed_keyResp_allKeys):
                prac_blockFeed_keyResp.keys = _prac_blockFeed_keyResp_allKeys[-1].name  # just the last key pressed
                prac_blockFeed_keyResp.rt = _prac_blockFeed_keyResp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in prac_blockFeedComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "prac_blockFeed" ---
    for thisComponent in prac_blockFeedComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # Run 'End Routine' code from prac_blockFeed_code
    if prac_blockFeed_keyResp.keys[-1] == 's':
        prac_block_loop.finished = True #end practice loop to continue to main exp
    # the Routine "prac_blockFeed" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 999 repeats of 'prac_block_loop'


# set up handler to look after randomisation of conditions etc
task_block_loop = data.TrialHandler(nReps=0.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('blockSelect.csv'),
    seed=None, name='task_block_loop')
thisExp.addLoop(task_block_loop)  # add the loop to the experiment
thisTask_block_loop = task_block_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTask_block_loop.rgb)
if thisTask_block_loop != None:
    for paramName in thisTask_block_loop:
        exec('{} = thisTask_block_loop[paramName]'.format(paramName))

for thisTask_block_loop in task_block_loop:
    currentLoop = task_block_loop
    # abbreviate parameter names if possible (e.g. rgb = thisTask_block_loop.rgb)
    if thisTask_block_loop != None:
        for paramName in thisTask_block_loop:
            exec('{} = thisTask_block_loop[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "eeg_trigger_check" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from triggerCheck_code
    #(re)open trigger port. This is done in case the connection failed,
    #in which case triggers will no longer be sent until the port is reopened.
    
    #At start of routine, we try to close/open the port. This will usually be
    #succesful, causing us to end the routine altogether. However, it will fail if 
    #the usb is unplugged. In this latter case, the routine will then run code each
    #frame to constantly check for the usb being plugged back in, before continuing.
    
    try: 
    #if usb connected, port will close/open and routine will end
        port.close()
        port.open()
        usbConnected = 1 #if successful, set usbConnectd to 1
        continueRoutine = False #if successful, end the routine
    
    except: #if port close/open fails, then set usbConnected to 0. Routine will loop each frame until fixed.
        usbConnected = 0 #if failure, set usbConnected to 0
    # keep track of which components have finished
    eeg_trigger_checkComponents = [triggerIssue_text]
    for thisComponent in eeg_trigger_checkComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "eeg_trigger_check" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from triggerCheck_code
        #if the usb is not connected, then keep trying to open port to determine when it has been reconnected.
        if usbConnected == 0:
            
            try: 
                #if usb connected, port will close/open and routine will end
                port.close()
                port.open()
                usbConnected = 1 #if successful, set usbConnectd to 1
                #send trigger to indicate that there was a connection issue that is now resolved
                port.write([0x63]) #hexcode = 99; eeg trigger sent
                time.sleep(PulseWidth) #how long to wait before clearing trigger port
                port.write([0x00]) #clear trigger port by sending hexcode = 0
                #if successful, end the routine
                continueRoutine = False
            
            except: #if usb not connected, routine will continue (keep checking port and keep showing message)
                usbConnected = 0 #if failure, set usbConnectd to 0
                time.sleep(0.5) #wait .5 secs before checking again, to not overload the system
        
        # *triggerIssue_text* updates
        if triggerIssue_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            triggerIssue_text.frameNStart = frameN  # exact frame index
            triggerIssue_text.tStart = t  # local t and not account for scr refresh
            triggerIssue_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(triggerIssue_text, 'tStartRefresh')  # time at next scr refresh
            triggerIssue_text.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in eeg_trigger_checkComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "eeg_trigger_check" ---
    for thisComponent in eeg_trigger_checkComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "eeg_trigger_check" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "task_blockReminders" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from task_blockReminder_code
    blockCounter = blockCounter +1
    
    if blockCounter == 1:
        blockNumText = 'Block 1 of 9'
    elif blockCounter == 2:
        blockNumText = 'Block 2 of 9'
    elif blockCounter == 3:
        blockNumText = 'Block 3 of 9'
    elif blockCounter == 4:
        blockNumText = 'Block 4 of 9'
    elif blockCounter == 5:
        blockNumText = 'Block 5 of 9'
    elif blockCounter == 6:
        blockNumText = 'Block 6 of 9'
    elif blockCounter == 7:
        blockNumText = 'Block 7 of 9'
    elif blockCounter == 8:
        blockNumText = 'Block 8 of 9'
    elif blockCounter == 9:
        blockNumText = 'Block 9 of 9'
    
    
    task_blockText.setText(blockNumText)
    task_blockReminders_keyResp.keys = []
    task_blockReminders_keyResp.rt = []
    _task_blockReminders_keyResp_allKeys = []
    # keep track of which components have finished
    task_blockRemindersComponents = [task_blockText, task_blockReminders_text, task_blockReminders_keyResp]
    for thisComponent in task_blockRemindersComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "task_blockReminders" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *task_blockText* updates
        if task_blockText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            task_blockText.frameNStart = frameN  # exact frame index
            task_blockText.tStart = t  # local t and not account for scr refresh
            task_blockText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(task_blockText, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'task_blockText.started')
            task_blockText.setAutoDraw(True)
        
        # *task_blockReminders_text* updates
        if task_blockReminders_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            task_blockReminders_text.frameNStart = frameN  # exact frame index
            task_blockReminders_text.tStart = t  # local t and not account for scr refresh
            task_blockReminders_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(task_blockReminders_text, 'tStartRefresh')  # time at next scr refresh
            task_blockReminders_text.setAutoDraw(True)
        
        # *task_blockReminders_keyResp* updates
        waitOnFlip = False
        if task_blockReminders_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            task_blockReminders_keyResp.frameNStart = frameN  # exact frame index
            task_blockReminders_keyResp.tStart = t  # local t and not account for scr refresh
            task_blockReminders_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(task_blockReminders_keyResp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'task_blockReminders_keyResp.started')
            task_blockReminders_keyResp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(task_blockReminders_keyResp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(task_blockReminders_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if task_blockReminders_keyResp.status == STARTED and not waitOnFlip:
            theseKeys = task_blockReminders_keyResp.getKeys(keyList=['8'], waitRelease=False)
            _task_blockReminders_keyResp_allKeys.extend(theseKeys)
            if len(_task_blockReminders_keyResp_allKeys):
                task_blockReminders_keyResp.keys = _task_blockReminders_keyResp_allKeys[-1].name  # just the last key pressed
                task_blockReminders_keyResp.rt = _task_blockReminders_keyResp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in task_blockRemindersComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "task_blockReminders" ---
    for thisComponent in task_blockRemindersComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if task_blockReminders_keyResp.keys in ['', [], None]:  # No response was made
        task_blockReminders_keyResp.keys = None
    task_block_loop.addData('task_blockReminders_keyResp.keys',task_blockReminders_keyResp.keys)
    if task_blockReminders_keyResp.keys != None:  # we had a response
        task_block_loop.addData('task_blockReminders_keyResp.rt', task_blockReminders_keyResp.rt)
    # the Routine "task_blockReminders" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "initFixation" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    initFixation_img.setImage('img/transp_fixation.png')
    # keep track of which components have finished
    initFixationComponents = [initFixation_img]
    for thisComponent in initFixationComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "initFixation" ---
    while continueRoutine and routineTimer.getTime() < 2.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *initFixation_img* updates
        if initFixation_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            initFixation_img.frameNStart = frameN  # exact frame index
            initFixation_img.tStart = t  # local t and not account for scr refresh
            initFixation_img.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(initFixation_img, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'initFixation_img.started')
            initFixation_img.setAutoDraw(True)
        if initFixation_img.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > initFixation_img.tStartRefresh + 2-frameTolerance:
                # keep track of stop time/frame for later
                initFixation_img.tStop = t  # not accounting for scr refresh
                initFixation_img.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'initFixation_img.stopped')
                initFixation_img.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in initFixationComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "initFixation" ---
    for thisComponent in initFixationComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-2.000000)
    
    # set up handler to look after randomisation of conditions etc
    task_trial_loop = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(whichBlock),
        seed=None, name='task_trial_loop')
    thisExp.addLoop(task_trial_loop)  # add the loop to the experiment
    thisTask_trial_loop = task_trial_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTask_trial_loop.rgb)
    if thisTask_trial_loop != None:
        for paramName in thisTask_trial_loop:
            exec('{} = thisTask_trial_loop[paramName]'.format(paramName))
    
    for thisTask_trial_loop in task_trial_loop:
        currentLoop = task_trial_loop
        # abbreviate parameter names if possible (e.g. rgb = thisTask_trial_loop.rgb)
        if thisTask_trial_loop != None:
            for paramName in thisTask_trial_loop:
                exec('{} = thisTask_trial_loop[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "task_stimRoutine" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # Run 'Begin Routine' code from task_isi_code
        # pick the ISI for the next routine
        # this code component is set to 'both' because we need to remove the 'np'
        # at the start of np.linspace (this is a python library JS won't know what to call. 
        
        # make range from a to b in n stepsizes
        ISIRange = np.linspace(3500, 4000, 500)
        
        # picking from a shuffled array is easier for random selection in JS
        shuffle(ISIRange)
        thisISI = ISIRange[0]/1000 # the first item of the shuffled array 
        
        # save this ISI to our output file
        task_trial_loop.addData('ISI', thisISI)
        
        main_background_face.setImage(straightFace)
        # Run 'Begin Routine' code from task_background_stim_trigger_code
        #set stimTriggerSent to false at the start of the trial. this way
        #when the stimulus is shown, we can change it to True. This variable
        #is used to ensure we only throw the stimulus EEG trigger once.
        stimTriggerSentZ1 = False
        task_centerImg.setPos((0, 0))
        task_centerImg.setSize([0.48, 0.48])
        task_centerImg.setImage(middleStim)
        task_rightImg1.setPos((0.567, 0))
        task_rightImg1.setSize([0.48, 0.48])
        task_rightImg1.setImage(rightStim)
        task_rightImg2.setPos((1.135, 0))
        task_rightImg2.setSize([0.48, 0.48])
        task_rightImg2.setImage(rightStim)
        task_leftImg1.setPos((-0.567, 0))
        task_leftImg1.setSize([0.48, 0.48])
        task_leftImg1.setImage(leftStim)
        task_leftImg2.setPos((-1.135, 0))
        task_leftImg2.setSize([0.48, 0.48])
        task_leftImg2.setImage(leftStim)
        task_fixImg.setImage('img/transp_fixation.png')
        # Run 'Begin Routine' code from task_stimTrigger_code
        #set stimTriggerSent to false at the start of the trial. this way
        #when the stimulus is shown, we can change it to True. This variable
        #is used to ensure we only throw the stimulus EEG trigger once.
        stimTriggerSent = False
        task1_stim_keyResp.keys = []
        task1_stim_keyResp.rt = []
        _task1_stim_keyResp_allKeys = []
        # Run 'Begin Routine' code from task_respTrigger_code
        #clear out the keys_counbted variable at the start of the trial
        #this variable will hold the keys that have had eeg triggers thrown
        #already within a given trial.
        keys_counted = []
        # keep track of which components have finished
        task_stimRoutineComponents = [main_background_face, main_cover_background, task_centerImg, task_rightImg1, task_rightImg2, task_leftImg1, task_leftImg2, task_fixImg, task1_stim_keyResp]
        for thisComponent in task_stimRoutineComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "task_stimRoutine" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *main_background_face* updates
            if main_background_face.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_background_face.frameNStart = frameN  # exact frame index
                main_background_face.tStart = t  # local t and not account for scr refresh
                main_background_face.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_background_face, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_background_face.started')
                main_background_face.setAutoDraw(True)
            if main_background_face.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_background_face.tStartRefresh + thisISI-frameTolerance:
                    # keep track of stop time/frame for later
                    main_background_face.tStop = t  # not accounting for scr refresh
                    main_background_face.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_background_face.stopped')
                    main_background_face.setAutoDraw(False)
            # Run 'Each Frame' code from task_background_stim_trigger_code
            #the first if statement below ensures that the subsequent if statements (and throwing of triggers)
            #only occurs once per trial. That is, only when the stimulus is presented (.status = STARTED) and
            #stimTriggerSent is still False. Once a trigger is sent, we change stimTriggerSentZ1 to True so that 
            #the stimulus eeg trigger will not be sent again for this trial
            if main_background_face.status == STARTED and not stimTriggerSentZ1:
                stimTriggerSentZ1 = True #switch stimTriggerSentZ1 to True so that the stimulus eeg trigger will not be sent again this trial
                port.write([0x0A]) #hexcode = 10; eeg trigger sent
                time.sleep(PulseWidth) #how long to wait before clearing trigger port
                port.write([0x00]) #clear trigger port by sending hexcode = 0
            
            
            # *main_cover_background* updates
            if main_cover_background.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                main_cover_background.frameNStart = frameN  # exact frame index
                main_cover_background.tStart = t  # local t and not account for scr refresh
                main_cover_background.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(main_cover_background, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'main_cover_background.started')
                main_cover_background.setAutoDraw(True)
            if main_cover_background.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > main_cover_background.tStartRefresh + 0.35-frameTolerance:
                    # keep track of stop time/frame for later
                    main_cover_background.tStop = t  # not accounting for scr refresh
                    main_cover_background.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'main_cover_background.stopped')
                    main_cover_background.setAutoDraw(False)
            
            # *task_centerImg* updates
            if task_centerImg.status == NOT_STARTED and tThisFlip >= 0.15-frameTolerance:
                # keep track of start time/frame for later
                task_centerImg.frameNStart = frameN  # exact frame index
                task_centerImg.tStart = t  # local t and not account for scr refresh
                task_centerImg.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(task_centerImg, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'task_centerImg.started')
                task_centerImg.setAutoDraw(True)
            if task_centerImg.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > task_centerImg.tStartRefresh + .2-frameTolerance:
                    # keep track of stop time/frame for later
                    task_centerImg.tStop = t  # not accounting for scr refresh
                    task_centerImg.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'task_centerImg.stopped')
                    task_centerImg.setAutoDraw(False)
            
            # *task_rightImg1* updates
            if task_rightImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                task_rightImg1.frameNStart = frameN  # exact frame index
                task_rightImg1.tStart = t  # local t and not account for scr refresh
                task_rightImg1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(task_rightImg1, 'tStartRefresh')  # time at next scr refresh
                task_rightImg1.setAutoDraw(True)
            if task_rightImg1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > task_rightImg1.tStartRefresh + .35-frameTolerance:
                    # keep track of stop time/frame for later
                    task_rightImg1.tStop = t  # not accounting for scr refresh
                    task_rightImg1.frameNStop = frameN  # exact frame index
                    task_rightImg1.setAutoDraw(False)
            
            # *task_rightImg2* updates
            if task_rightImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                task_rightImg2.frameNStart = frameN  # exact frame index
                task_rightImg2.tStart = t  # local t and not account for scr refresh
                task_rightImg2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(task_rightImg2, 'tStartRefresh')  # time at next scr refresh
                task_rightImg2.setAutoDraw(True)
            if task_rightImg2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > task_rightImg2.tStartRefresh + .350-frameTolerance:
                    # keep track of stop time/frame for later
                    task_rightImg2.tStop = t  # not accounting for scr refresh
                    task_rightImg2.frameNStop = frameN  # exact frame index
                    task_rightImg2.setAutoDraw(False)
            
            # *task_leftImg1* updates
            if task_leftImg1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                task_leftImg1.frameNStart = frameN  # exact frame index
                task_leftImg1.tStart = t  # local t and not account for scr refresh
                task_leftImg1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(task_leftImg1, 'tStartRefresh')  # time at next scr refresh
                task_leftImg1.setAutoDraw(True)
            if task_leftImg1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > task_leftImg1.tStartRefresh + .35-frameTolerance:
                    # keep track of stop time/frame for later
                    task_leftImg1.tStop = t  # not accounting for scr refresh
                    task_leftImg1.frameNStop = frameN  # exact frame index
                    task_leftImg1.setAutoDraw(False)
            
            # *task_leftImg2* updates
            if task_leftImg2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                task_leftImg2.frameNStart = frameN  # exact frame index
                task_leftImg2.tStart = t  # local t and not account for scr refresh
                task_leftImg2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(task_leftImg2, 'tStartRefresh')  # time at next scr refresh
                task_leftImg2.setAutoDraw(True)
            if task_leftImg2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > task_leftImg2.tStartRefresh + .350-frameTolerance:
                    # keep track of stop time/frame for later
                    task_leftImg2.tStop = t  # not accounting for scr refresh
                    task_leftImg2.frameNStop = frameN  # exact frame index
                    task_leftImg2.setAutoDraw(False)
            
            # *task_fixImg* updates
            if task_fixImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                task_fixImg.frameNStart = frameN  # exact frame index
                task_fixImg.tStart = t  # local t and not account for scr refresh
                task_fixImg.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(task_fixImg, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'task_fixImg.started')
                task_fixImg.setAutoDraw(True)
            if task_fixImg.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > task_fixImg.tStartRefresh + thisISI-frameTolerance:
                    # keep track of stop time/frame for later
                    task_fixImg.tStop = t  # not accounting for scr refresh
                    task_fixImg.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'task_fixImg.stopped')
                    task_fixImg.setAutoDraw(False)
            # Run 'Each Frame' code from task_stimTrigger_code
            #the first if statement below ensures that the subsequent if statements (and throwing of triggers)
            #only occurs once per trial. That is, only when the stimulus is presented (.status = STARTED) and
            #stimTriggerSent is still False. Once a trigger is sent, we change stimTriggerSent to True so that 
            #the stimulus eeg trigger will not be sent again for this trial
            if task_centerImg.status == STARTED and not stimTriggerSent:
                if stimNum == 5: #code denoting which stimulus array was sent (from excel file)
                    stimTriggerSent = True #switch stimTriggerSent to True so that the stimulus eeg trigger will not be sent again this trial
                    port.write([0x05]) #hexcode = 5; eeg trigger sent
                    time.sleep(PulseWidth) #how long to wait before clearing trigger port
                    port.write([0x00]) #clear trigger port by sending hexcode = 0
                elif stimNum == 6:
                    stimTriggerSent = True
                    port.write([0x06]) #hexcode = 6;
                    time.sleep(PulseWidth)
                    port.write([0x00])
                elif stimNum == 7:
                    stimTriggerSent = True
                    port.write([0x07]) #hexcode = 7;
                    time.sleep(PulseWidth)
                    port.write([0x00])
                elif stimNum == 8:
                    stimTriggerSent = True
                    port.write([0x08]) #hexcode = 8;
                    time.sleep(PulseWidth)
                    port.write([0x00])
            
            # *task1_stim_keyResp* updates
            waitOnFlip = False
            if task1_stim_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                task1_stim_keyResp.frameNStart = frameN  # exact frame index
                task1_stim_keyResp.tStart = t  # local t and not account for scr refresh
                task1_stim_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(task1_stim_keyResp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'task1_stim_keyResp.started')
                task1_stim_keyResp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(task1_stim_keyResp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(task1_stim_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if task1_stim_keyResp.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > task1_stim_keyResp.tStartRefresh + thisISI-frameTolerance:
                    # keep track of stop time/frame for later
                    task1_stim_keyResp.tStop = t  # not accounting for scr refresh
                    task1_stim_keyResp.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'task1_stim_keyResp.stopped')
                    task1_stim_keyResp.status = FINISHED
            if task1_stim_keyResp.status == STARTED and not waitOnFlip:
                theseKeys = task1_stim_keyResp.getKeys(keyList=['1','8'], waitRelease=False)
                _task1_stim_keyResp_allKeys.extend(theseKeys)
                if len(_task1_stim_keyResp_allKeys):
                    task1_stim_keyResp.keys = [key.name for key in _task1_stim_keyResp_allKeys]  # storing all keys
                    task1_stim_keyResp.rt = [key.rt for key in _task1_stim_keyResp_allKeys]
            # Run 'Each Frame' code from task_respTrigger_code
            if task1_stim_keyResp.keys and len(task1_stim_keyResp.keys) > len(keys_counted):# A key response has been made but we haven't yet "counted" it
                keys_counted.append(task1_stim_keyResp.keys[-1]) #add this response to list of keys pressed this trial
                if len(task1_stim_keyResp.keys) < 2: #if this is  the first response
                    if task1_stim_keyResp.keys[-1] == '1':
                        if target == 'left': #correct response
                            port.write([0x0B]) # 11
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'right': #error response
                            port.write([0x0C])# 12
                            time.sleep(PulseWidth)
                            port.write([0x00])
                    elif task1_stim_keyResp.keys[-1] == '8':
                        if target == 'right': #correct response
                            port.write([0x0B]) # 11
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'left': #error response
                            port.write([0x0C])# 12
                            time.sleep(PulseWidth)
                            port.write([0x00])
                elif len(task1_stim_keyResp.keys) >= 2: #if this is NOT the first response
                    if task1_stim_keyResp.keys[-1] == '1':
                        if target == 'left': #technically correct response, but not the first response made
                            port.write([0x15]) # 21
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'right': #technically error response, but not the first response made
                            port.write([0x16])# 22
                            time.sleep(PulseWidth)
                            port.write([0x00])
                    elif task1_stim_keyResp.keys[-1] == '8':
                        if target == 'right': #technically correct response, but not the first response made
                            port.write([0x15]) # 21
                            time.sleep(PulseWidth)
                            port.write([0x00])
                        elif target == 'left': #technically error response, but not the first response made
                            port.write([0x16])# 22
                            time.sleep(PulseWidth)
                            port.write([0x00])
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in task_stimRoutineComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "task_stimRoutine" ---
        for thisComponent in task_stimRoutineComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if task1_stim_keyResp.keys in ['', [], None]:  # No response was made
            task1_stim_keyResp.keys = None
        task_trial_loop.addData('task1_stim_keyResp.keys',task1_stim_keyResp.keys)
        if task1_stim_keyResp.keys != None:  # we had a response
            task_trial_loop.addData('task1_stim_keyResp.rt', task1_stim_keyResp.rt)
        # Run 'End Routine' code from task_respTrigger_code
        
        #instead of including here, should instead include something
        #in each frame section that computes t at stim onset and then
        #when thisISI - t <= .05 (50 ms) and then at that point we throw
        #the no-resp marker...
        
        #if not prac_stim_keyResp.keys or len(prac_stim_keyResp.keys) == 0:
        #            port.write([0x63]) # 99
        #            time.sleep(PulseWidth)
        #            port.write([0x00])
        # Run 'End Routine' code from task_accuracy_code
        trialNum = trialNum + 1 #iterate trial number for this block
        
        if task1_stim_keyResp.keys: #if at least one response was made this trial
            if task1_stim_keyResp.keys[0] == '1': #if the FIRST button pressed was a '1'
                if target == 'left': #if a left target stim was shown this trial
                    accuracy = 1 #mark this trial as correct
                    numCorr = numCorr +1 #iterate number of correct responses for this block
                elif target == 'right': #if a right target stim was shown this trial
                    accuracy = 0 #mark this trial as an error
            elif task1_stim_keyResp.keys[0] == '8': #if the FIRST button pressed was a '8'
                if target == 'right': #if a right target stim was shown this trial
                    accuracy = 1 #mark this trial as correct
                    numCorr = numCorr +1 #iterate number of correct responses for this block
                elif target == 'left': #if a left target stim was shown this trial
                    accuracy = 0 #mark this trial as an error
        elif not task1_stim_keyResp.keys: # if no response was made
            accuracy = 0
                    
        # save this trial's accuracy to our output file
        task_trial_loop.addData('accuracy', accuracy)
        # the Routine "task_stimRoutine" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'task_trial_loop'
    
    
    # --- Prepare to start Routine "task_blockFeed" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from task_blockFeed_code
    blockAcc = numCorr / trialNum #compute accuracy for this block
    
    if blockCounter < 10:
        if blockAcc >= .75:
            if blockAcc < .9:
                blockFeed = 'Good job'
                blockFeedCat = 1
            elif blockAcc >= .9:
                blockFeed = 'Respond faster'
                blockFeedCat = 2
        elif blockAcc < .75:
            blockFeed = 'Respond more accurately'
            blockFeedCat = 3
    elif blockCounter == 10:
        'You have completed all blocks'
    
    # save this block's feedback to our output file
    task_trial_loop.addData('blockFeedCat', blockFeedCat)
    
    #reset the following variables to zero before next block starts
    trialNum = 0
    numCorr = 0
    task_blockFeed_text.setText(blockFeed)
    task_blockFeed_text2.setText('Press the right button')
    task_blockFeed_keyResp.keys = []
    task_blockFeed_keyResp.rt = []
    _task_blockFeed_keyResp_allKeys = []
    # keep track of which components have finished
    task_blockFeedComponents = [task_blockFeed_text, task_blockFeed_text2, task_blockFeed_keyResp]
    for thisComponent in task_blockFeedComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "task_blockFeed" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *task_blockFeed_text* updates
        if task_blockFeed_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            task_blockFeed_text.frameNStart = frameN  # exact frame index
            task_blockFeed_text.tStart = t  # local t and not account for scr refresh
            task_blockFeed_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(task_blockFeed_text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'task_blockFeed_text.started')
            task_blockFeed_text.setAutoDraw(True)
        
        # *task_blockFeed_text2* updates
        if task_blockFeed_text2.status == NOT_STARTED and tThisFlip >= 10-frameTolerance:
            # keep track of start time/frame for later
            task_blockFeed_text2.frameNStart = frameN  # exact frame index
            task_blockFeed_text2.tStart = t  # local t and not account for scr refresh
            task_blockFeed_text2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(task_blockFeed_text2, 'tStartRefresh')  # time at next scr refresh
            task_blockFeed_text2.setAutoDraw(True)
        
        # *task_blockFeed_keyResp* updates
        waitOnFlip = False
        if task_blockFeed_keyResp.status == NOT_STARTED and tThisFlip >= 10-frameTolerance:
            # keep track of start time/frame for later
            task_blockFeed_keyResp.frameNStart = frameN  # exact frame index
            task_blockFeed_keyResp.tStart = t  # local t and not account for scr refresh
            task_blockFeed_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(task_blockFeed_keyResp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'task_blockFeed_keyResp.started')
            task_blockFeed_keyResp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(task_blockFeed_keyResp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(task_blockFeed_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if task_blockFeed_keyResp.status == STARTED and not waitOnFlip:
            theseKeys = task_blockFeed_keyResp.getKeys(keyList=['8'], waitRelease=False)
            _task_blockFeed_keyResp_allKeys.extend(theseKeys)
            if len(_task_blockFeed_keyResp_allKeys):
                task_blockFeed_keyResp.keys = _task_blockFeed_keyResp_allKeys[-1].name  # just the last key pressed
                task_blockFeed_keyResp.rt = _task_blockFeed_keyResp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in task_blockFeedComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "task_blockFeed" ---
    for thisComponent in task_blockFeedComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if task_blockFeed_keyResp.keys in ['', [], None]:  # No response was made
        task_blockFeed_keyResp.keys = None
    task_block_loop.addData('task_blockFeed_keyResp.keys',task_blockFeed_keyResp.keys)
    if task_blockFeed_keyResp.keys != None:  # we had a response
        task_block_loop.addData('task_blockFeed_keyResp.rt', task_blockFeed_keyResp.rt)
    # the Routine "task_blockFeed" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 0.0 repeats of 'task_block_loop'


# --- Prepare to start Routine "fixation1" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# Run 'Begin Routine' code from code_2
event.clearEvents()
# keep track of which components have finished
fixation1Components = [fix]
for thisComponent in fixation1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "fixation1" ---
while continueRoutine and routineTimer.getTime() < 0.5:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *fix* updates
    if fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        fix.frameNStart = frameN  # exact frame index
        fix.tStart = t  # local t and not account for scr refresh
        fix.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(fix, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'fix.started')
        fix.setAutoDraw(True)
    if fix.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > fix.tStartRefresh + 0.5-frameTolerance:
            # keep track of stop time/frame for later
            fix.tStop = t  # not accounting for scr refresh
            fix.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fix.stopped')
            fix.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in fixation1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "fixation1" ---
for thisComponent in fixation1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-0.500000)

# --- Prepare to start Routine "errorNumbers" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# Run 'Begin Routine' code from code
event.clearEvents()
errorNum_box.reset()
errorNums_key_resp.keys = []
errorNums_key_resp.rt = []
_errorNums_key_resp_allKeys = []
# keep track of which components have finished
errorNumbersComponents = [errorNumbers_text, errorNum_box, errorNums_key_resp]
for thisComponent in errorNumbersComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "errorNumbers" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *errorNumbers_text* updates
    if errorNumbers_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        errorNumbers_text.frameNStart = frameN  # exact frame index
        errorNumbers_text.tStart = t  # local t and not account for scr refresh
        errorNumbers_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(errorNumbers_text, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'errorNumbers_text.started')
        errorNumbers_text.setAutoDraw(True)
    
    # *errorNum_box* updates
    if errorNum_box.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        errorNum_box.frameNStart = frameN  # exact frame index
        errorNum_box.tStart = t  # local t and not account for scr refresh
        errorNum_box.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(errorNum_box, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'errorNum_box.started')
        errorNum_box.setAutoDraw(True)
    
    # *errorNums_key_resp* updates
    waitOnFlip = False
    if errorNums_key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        errorNums_key_resp.frameNStart = frameN  # exact frame index
        errorNums_key_resp.tStart = t  # local t and not account for scr refresh
        errorNums_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(errorNums_key_resp, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'errorNums_key_resp.started')
        errorNums_key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(errorNums_key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(errorNums_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if errorNums_key_resp.status == STARTED and not waitOnFlip:
        theseKeys = errorNums_key_resp.getKeys(keyList=['c'], waitRelease=False)
        _errorNums_key_resp_allKeys.extend(theseKeys)
        if len(_errorNums_key_resp_allKeys):
            errorNums_key_resp.keys = _errorNums_key_resp_allKeys[-1].name  # just the last key pressed
            errorNums_key_resp.rt = _errorNums_key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in errorNumbersComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "errorNumbers" ---
for thisComponent in errorNumbersComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('errorNum_box.text',errorNum_box.text)
# check responses
if errorNums_key_resp.keys in ['', [], None]:  # No response was made
    errorNums_key_resp.keys = None
thisExp.addData('errorNums_key_resp.keys',errorNums_key_resp.keys)
if errorNums_key_resp.keys != None:  # we had a response
    thisExp.addData('errorNums_key_resp.rt', errorNums_key_resp.rt)
thisExp.nextEntry()
# the Routine "errorNumbers" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "surpriseInstruct" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruct_surp_key_resp1.keys = []
instruct_surp_key_resp1.rt = []
_instruct_surp_key_resp1_allKeys = []
# keep track of which components have finished
surpriseInstructComponents = [instruct_surp1, instruct_surp_key_resp1]
for thisComponent in surpriseInstructComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "surpriseInstruct" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruct_surp1* updates
    if instruct_surp1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruct_surp1.frameNStart = frameN  # exact frame index
        instruct_surp1.tStart = t  # local t and not account for scr refresh
        instruct_surp1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruct_surp1, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'instruct_surp1.started')
        instruct_surp1.setAutoDraw(True)
    
    # *instruct_surp_key_resp1* updates
    waitOnFlip = False
    if instruct_surp_key_resp1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruct_surp_key_resp1.frameNStart = frameN  # exact frame index
        instruct_surp_key_resp1.tStart = t  # local t and not account for scr refresh
        instruct_surp_key_resp1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruct_surp_key_resp1, 'tStartRefresh')  # time at next scr refresh
        instruct_surp_key_resp1.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instruct_surp_key_resp1.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instruct_surp_key_resp1.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instruct_surp_key_resp1.status == STARTED and not waitOnFlip:
        theseKeys = instruct_surp_key_resp1.getKeys(keyList=['c'], waitRelease=False)
        _instruct_surp_key_resp1_allKeys.extend(theseKeys)
        if len(_instruct_surp_key_resp1_allKeys):
            instruct_surp_key_resp1.keys = _instruct_surp_key_resp1_allKeys[-1].name  # just the last key pressed
            instruct_surp_key_resp1.rt = _instruct_surp_key_resp1_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in surpriseInstructComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "surpriseInstruct" ---
for thisComponent in surpriseInstructComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if instruct_surp_key_resp1.keys in ['', [], None]:  # No response was made
    instruct_surp_key_resp1.keys = None
thisExp.addData('instruct_surp_key_resp1.keys',instruct_surp_key_resp1.keys)
if instruct_surp_key_resp1.keys != None:  # we had a response
    thisExp.addData('instruct_surp_key_resp1.rt', instruct_surp_key_resp1.rt)
thisExp.nextEntry()
# the Routine "surpriseInstruct" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "surpriseInstruct2" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
instruct_surp_key_resp2.keys = []
instruct_surp_key_resp2.rt = []
_instruct_surp_key_resp2_allKeys = []
# keep track of which components have finished
surpriseInstruct2Components = [instruct_surp2, instruct_surp_key_resp2]
for thisComponent in surpriseInstruct2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "surpriseInstruct2" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instruct_surp2* updates
    if instruct_surp2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruct_surp2.frameNStart = frameN  # exact frame index
        instruct_surp2.tStart = t  # local t and not account for scr refresh
        instruct_surp2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruct_surp2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'instruct_surp2.started')
        instruct_surp2.setAutoDraw(True)
    
    # *instruct_surp_key_resp2* updates
    waitOnFlip = False
    if instruct_surp_key_resp2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instruct_surp_key_resp2.frameNStart = frameN  # exact frame index
        instruct_surp_key_resp2.tStart = t  # local t and not account for scr refresh
        instruct_surp_key_resp2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instruct_surp_key_resp2, 'tStartRefresh')  # time at next scr refresh
        instruct_surp_key_resp2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(instruct_surp_key_resp2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(instruct_surp_key_resp2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if instruct_surp_key_resp2.status == STARTED and not waitOnFlip:
        theseKeys = instruct_surp_key_resp2.getKeys(keyList=['c'], waitRelease=False)
        _instruct_surp_key_resp2_allKeys.extend(theseKeys)
        if len(_instruct_surp_key_resp2_allKeys):
            instruct_surp_key_resp2.keys = _instruct_surp_key_resp2_allKeys[-1].name  # just the last key pressed
            instruct_surp_key_resp2.rt = _instruct_surp_key_resp2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in surpriseInstruct2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "surpriseInstruct2" ---
for thisComponent in surpriseInstruct2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if instruct_surp_key_resp2.keys in ['', [], None]:  # No response was made
    instruct_surp_key_resp2.keys = None
thisExp.addData('instruct_surp_key_resp2.keys',instruct_surp_key_resp2.keys)
if instruct_surp_key_resp2.keys != None:  # we had a response
    thisExp.addData('instruct_surp_key_resp2.rt', instruct_surp_key_resp2.rt)
thisExp.nextEntry()
# the Routine "surpriseInstruct2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
surprise_block_loop = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions("surpriseBlock_select_"+expInfo['cb']+".xlsx"),
    seed=None, name='surprise_block_loop')
thisExp.addLoop(surprise_block_loop)  # add the loop to the experiment
thisSurprise_block_loop = surprise_block_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisSurprise_block_loop.rgb)
if thisSurprise_block_loop != None:
    for paramName in thisSurprise_block_loop:
        exec('{} = thisSurprise_block_loop[paramName]'.format(paramName))

for thisSurprise_block_loop in surprise_block_loop:
    currentLoop = surprise_block_loop
    # abbreviate parameter names if possible (e.g. rgb = thisSurprise_block_loop.rgb)
    if thisSurprise_block_loop != None:
        for paramName in thisSurprise_block_loop:
            exec('{} = thisSurprise_block_loop[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "surpriseInstruct3" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from shuffling_surprise
    port.close()
    port.open()
    
    blockCounterZ1 = blockCounterZ1 +1
    
    if blockCounterZ1 == 1:
        blockNumText = 'Block 1 of 4'
    elif blockCounterZ1 == 2:
        blockNumText = 'Block 2 of 4'
    elif blockCounterZ1 == 3:
        blockNumText = 'Block 3 of 4'
    elif blockCounterZ1 == 4:
        blockNumText = 'Block 4 of 4'
    instruct_surp3_1.setText(blockNumText)
    instruct_surp3_2.setText('To get ready, rest your right and left thumbs on the right and left buttons, then press the right button when you are ready to begin.')
    instructMainTask_keyResp.keys = []
    instructMainTask_keyResp.rt = []
    _instructMainTask_keyResp_allKeys = []
    # keep track of which components have finished
    surpriseInstruct3Components = [instruct_surp3_1, instruct_surp3_2, instructMainTask_keyResp]
    for thisComponent in surpriseInstruct3Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "surpriseInstruct3" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instruct_surp3_1* updates
        if instruct_surp3_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct_surp3_1.frameNStart = frameN  # exact frame index
            instruct_surp3_1.tStart = t  # local t and not account for scr refresh
            instruct_surp3_1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct_surp3_1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct_surp3_1.started')
            instruct_surp3_1.setAutoDraw(True)
        
        # *instruct_surp3_2* updates
        if instruct_surp3_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct_surp3_2.frameNStart = frameN  # exact frame index
            instruct_surp3_2.tStart = t  # local t and not account for scr refresh
            instruct_surp3_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct_surp3_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instruct_surp3_2.started')
            instruct_surp3_2.setAutoDraw(True)
        
        # *instructMainTask_keyResp* updates
        waitOnFlip = False
        if instructMainTask_keyResp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instructMainTask_keyResp.frameNStart = frameN  # exact frame index
            instructMainTask_keyResp.tStart = t  # local t and not account for scr refresh
            instructMainTask_keyResp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instructMainTask_keyResp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instructMainTask_keyResp.started')
            instructMainTask_keyResp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(instructMainTask_keyResp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(instructMainTask_keyResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if instructMainTask_keyResp.status == STARTED and not waitOnFlip:
            theseKeys = instructMainTask_keyResp.getKeys(keyList=['8'], waitRelease=False)
            _instructMainTask_keyResp_allKeys.extend(theseKeys)
            if len(_instructMainTask_keyResp_allKeys):
                instructMainTask_keyResp.keys = _instructMainTask_keyResp_allKeys[-1].name  # just the last key pressed
                instructMainTask_keyResp.rt = _instructMainTask_keyResp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in surpriseInstruct3Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "surpriseInstruct3" ---
    for thisComponent in surpriseInstruct3Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if instructMainTask_keyResp.keys in ['', [], None]:  # No response was made
        instructMainTask_keyResp.keys = None
    surprise_block_loop.addData('instructMainTask_keyResp.keys',instructMainTask_keyResp.keys)
    if instructMainTask_keyResp.keys != None:  # we had a response
        surprise_block_loop.addData('instructMainTask_keyResp.rt', instructMainTask_keyResp.rt)
    # the Routine "surpriseInstruct3" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "fixation2" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    # Run 'Begin Routine' code from code_4
    event.clearEvents()
    # make range from a to b in n stepsizes
    ISIRange_surp = np.linspace(800, 1200, 400)
    
    # picking from a shuffled array is easier for random selection in JS
    shuffle(ISIRange_surp)
    thisISI_surp = ISIRange_surp[0]/1000 # the first item of the shuffled array 
    surprise_block_loop.addData('thisISI_surp', thisISI_surp)
    # Run 'Begin Routine' code from fixation_trig
    #set stimTriggerSent to false at the start of the trial. this way
    #when the stimulus is shown, we can change it to True. This variable
    #is used to ensure we only throw the stimulus EEG trigger once.
    stimulusTriggerSentQ1 = False
    # keep track of which components have finished
    fixation2Components = [fix2]
    for thisComponent in fixation2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "fixation2" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *fix2* updates
        if fix2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            fix2.frameNStart = frameN  # exact frame index
            fix2.tStart = t  # local t and not account for scr refresh
            fix2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fix2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fix2.started')
            fix2.setAutoDraw(True)
        if fix2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > fix2.tStartRefresh + thisISI_surp-frameTolerance:
                # keep track of stop time/frame for later
                fix2.tStop = t  # not accounting for scr refresh
                fix2.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fix2.stopped')
                fix2.setAutoDraw(False)
        # Run 'Each Frame' code from fixation_trig
        
        if fix2.status == STARTED and not stimulusTriggerSentQ1:
            stimulusTriggerSentQ1 = True #switch stimTriggerSent to True so that the stimulus eeg trigger will not be sent again this trial
            port.write([0x3D]) #hexcode = 61; eeg trigger sent
            time.sleep(PulseWidth) #how long to wait before clearing trigger port
            port.write([0x00]) #clear trigger port by sending hexcode = 0
        
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in fixation2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "fixation2" ---
    for thisComponent in fixation2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "fixation2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(whichSurpriseBlock),
        seed=None, name='trials')
    thisExp.addLoop(trials)  # add the loop to the experiment
    thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    for thisTrial in trials:
        currentLoop = trials
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                exec('{} = thisTrial[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "surpriseTask" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        stimulus.setImage(surpriseFaces)
        instructsurpA1_right.setPos((9, -0.5))
        instructsurpA1_right.setText(instructsurpA1)
        instructsurpA2_left.setText(instructsurpA2)
        # Run 'Begin Routine' code from stimulus_trig_code
        #set stimTriggerSent to false at the start of the trial. this way
        #when the stimulus is shown, we can change it to True. This variable
        #is used to ensure we only throw the stimulus EEG trigger once.
        stimulusTriggerSent = False
        surprise_key_resp.keys = []
        surprise_key_resp.rt = []
        _surprise_key_resp_allKeys = []
        # Run 'Begin Routine' code from response_trigger_code
        #clear out the keys_counbted variable at the start of the trial
        #this variable will hold the keys that have had eeg triggers thrown
        #already within a given trial.
        keys_counted = []
        # keep track of which components have finished
        surpriseTaskComponents = [stimulus, instructsurpA1_right, instructsurpA2_left, surprise_key_resp]
        for thisComponent in surpriseTaskComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "surpriseTask" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *stimulus* updates
            if stimulus.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                stimulus.frameNStart = frameN  # exact frame index
                stimulus.tStart = t  # local t and not account for scr refresh
                stimulus.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(stimulus, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'stimulus.started')
                stimulus.setAutoDraw(True)
            
            # *instructsurpA1_right* updates
            if instructsurpA1_right.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                instructsurpA1_right.frameNStart = frameN  # exact frame index
                instructsurpA1_right.tStart = t  # local t and not account for scr refresh
                instructsurpA1_right.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(instructsurpA1_right, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'instructsurpA1_right.started')
                instructsurpA1_right.setAutoDraw(True)
            
            # *instructsurpA2_left* updates
            if instructsurpA2_left.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                instructsurpA2_left.frameNStart = frameN  # exact frame index
                instructsurpA2_left.tStart = t  # local t and not account for scr refresh
                instructsurpA2_left.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(instructsurpA2_left, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'instructsurpA2_left.started')
                instructsurpA2_left.setAutoDraw(True)
            # Run 'Each Frame' code from stimulus_trig_code
            
            if stimulus.status == STARTED and not stimulusTriggerSent:
                stimulusTriggerSent = True #switch stimTriggerSent to True so that the stimulus eeg trigger will not be sent again this trial
                port.write([0x1F]) #hexcode = 31; eeg trigger sent
                time.sleep(PulseWidth) #how long to wait before clearing trigger port
                port.write([0x00]) #clear trigger port by sending hexcode = 0
            
            
            # *surprise_key_resp* updates
            waitOnFlip = False
            if surprise_key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                surprise_key_resp.frameNStart = frameN  # exact frame index
                surprise_key_resp.tStart = t  # local t and not account for scr refresh
                surprise_key_resp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(surprise_key_resp, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'surprise_key_resp.started')
                surprise_key_resp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(surprise_key_resp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(surprise_key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if surprise_key_resp.status == STARTED and not waitOnFlip:
                theseKeys = surprise_key_resp.getKeys(keyList=['1','8'], waitRelease=False)
                _surprise_key_resp_allKeys.extend(theseKeys)
                if len(_surprise_key_resp_allKeys):
                    surprise_key_resp.keys = _surprise_key_resp_allKeys[-1].name  # just the last key pressed
                    surprise_key_resp.rt = _surprise_key_resp_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            # Run 'Each Frame' code from response_trigger_code
            if surprise_key_resp.keys and len(surprise_key_resp.keys) > len(keys_counted):# A key response has been made but we haven't yet "counted" it
                keys_counted.append(surprise_key_resp.keys[-1]) #add this response to list of keys pressed this trial
                if len(surprise_key_resp.keys) < 2: #if this is  the first response
                    if surprise_key_resp.keys[-1] == '1':
                        port.write([0x29]) # 41
                        time.sleep(PulseWidth)
                        port.write([0x00])
                    elif surprise_key_resp.keys[-1] == '8': 
                        port.write([0x2A])# 42
                        time.sleep(PulseWidth)
                        port.write([0x00])
                elif len(surprise_key_resp.keys) >= 2: #if this is NOT the first response
                    if surprise_key_resp.keys[-1] == '1':
                        port.write([0x33]) # 51
                        time.sleep(PulseWidth)
                        port.write([0x00])
                    elif surprise_key_resp.keys[-1] == '8': 
                        port.write([0x34])# 52
                        time.sleep(PulseWidth)
                        port.write([0x00])
            
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in surpriseTaskComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "surpriseTask" ---
        for thisComponent in surpriseTaskComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if surprise_key_resp.keys in ['', [], None]:  # No response was made
            surprise_key_resp.keys = None
        trials.addData('surprise_key_resp.keys',surprise_key_resp.keys)
        if surprise_key_resp.keys != None:  # we had a response
            trials.addData('surprise_key_resp.rt', surprise_key_resp.rt)
        # Run 'End Routine' code from response_trigger_code
        
        #instead of including here, should instead include something
        #in each frame section that computes t at stim onset and then
        #when thisISI - t <= .05 (50 ms) and then at that point we throw
        #the no-resp marker...
        
        #if not prac_stim_keyResp.keys or len(prac_stim_keyResp.keys) == 0:
        #            port.write([0x63]) # 99
        #            time.sleep(PulseWidth)
        #            port.write([0x00])
        # the Routine "surpriseTask" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "fixation2" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code_4
        event.clearEvents()
        # make range from a to b in n stepsizes
        ISIRange_surp = np.linspace(800, 1200, 400)
        
        # picking from a shuffled array is easier for random selection in JS
        shuffle(ISIRange_surp)
        thisISI_surp = ISIRange_surp[0]/1000 # the first item of the shuffled array 
        surprise_block_loop.addData('thisISI_surp', thisISI_surp)
        # Run 'Begin Routine' code from fixation_trig
        #set stimTriggerSent to false at the start of the trial. this way
        #when the stimulus is shown, we can change it to True. This variable
        #is used to ensure we only throw the stimulus EEG trigger once.
        stimulusTriggerSentQ1 = False
        # keep track of which components have finished
        fixation2Components = [fix2]
        for thisComponent in fixation2Components:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "fixation2" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fix2* updates
            if fix2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fix2.frameNStart = frameN  # exact frame index
                fix2.tStart = t  # local t and not account for scr refresh
                fix2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fix2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fix2.started')
                fix2.setAutoDraw(True)
            if fix2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fix2.tStartRefresh + thisISI_surp-frameTolerance:
                    # keep track of stop time/frame for later
                    fix2.tStop = t  # not accounting for scr refresh
                    fix2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix2.stopped')
                    fix2.setAutoDraw(False)
            # Run 'Each Frame' code from fixation_trig
            
            if fix2.status == STARTED and not stimulusTriggerSentQ1:
                stimulusTriggerSentQ1 = True #switch stimTriggerSent to True so that the stimulus eeg trigger will not be sent again this trial
                port.write([0x3D]) #hexcode = 61; eeg trigger sent
                time.sleep(PulseWidth) #how long to wait before clearing trigger port
                port.write([0x00]) #clear trigger port by sending hexcode = 0
            
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in fixation2Components:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "fixation2" ---
        for thisComponent in fixation2Components:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "fixation2" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trials'
    
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'surprise_block_loop'


# --- Prepare to start Routine "finishMessage" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# keep track of which components have finished
finishMessageComponents = [finishMessage_text]
for thisComponent in finishMessageComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "finishMessage" ---
while continueRoutine and routineTimer.getTime() < 3.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *finishMessage_text* updates
    if finishMessage_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        finishMessage_text.frameNStart = frameN  # exact frame index
        finishMessage_text.tStart = t  # local t and not account for scr refresh
        finishMessage_text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(finishMessage_text, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'finishMessage_text.started')
        finishMessage_text.setAutoDraw(True)
    if finishMessage_text.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > finishMessage_text.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            finishMessage_text.tStop = t  # not accounting for scr refresh
            finishMessage_text.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'finishMessage_text.stopped')
            finishMessage_text.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in finishMessageComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "finishMessage" ---
for thisComponent in finishMessageComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-3.000000)
# Run 'End Experiment' code from setup_code
win.mouseVisible = True #make the mouse cursor visable again
port.write([0xFF]) #set port values back to default state (FF)
time.sleep(PulseWidth) #wait PulseWidth amount of time before doing anything else
port.close() #close port opened at start of exp

# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
