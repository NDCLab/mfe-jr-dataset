% =========================================================================
% SCRIPT: prepare_flanker_memory_stimuli.m
%
% PURPOSE:
% This script automates the generation of stimulus trial lists (CSV files)
% for a psychological experiment involving an Eriksen flanker task followed
% by a surprise recognition memory task. It uses neutral face images as
% background stimuli during the flanker task.
%
% TASKS PERFORMED:
% 1. Configures experiment parameters (paths, trial counts, stimuli, output location).
% 2. Loads neutral face image file paths from a specified directory.
% 3. Randomly selects faces for use in practice and main flanker trials.
% 4. Identifies unused faces (potential foils).
% 5. Generates CSV files for each flanker task block (practice and main),
%    defining trial parameters (arrows, congruency, face image, locations)
%    and randomizing trial order.
% 6. Selects foil faces for the memory task: Number of foils = floor(Number of unique faces shown in main blocks / 2).
% 7. Generates CSV files (4 blocks) for the surprise memory task, distributing
%    'old' and 'new' (foil) faces as evenly as possible across blocks,
%    then shuffling within each block before saving.
%
% AUTHORS: Kianoosh Hosseini (NDClab) - Original version May 2022
% REVISED BY: Kianoosh Hosseini and Gemini AI (version: 2.5 Pro)
% LAST REVISION DATE: April 8, 2025 
% =========================================================================

%% Configuration Section
% =========================================================================
% This section defines all user-adjustable parameters for the experiment.
% Modify these values to suit your specific setup and design.
% =========================================================================
fprintf('Setting up configuration...\n'); % Display status message
% --- Paths and File Patterns ---
cfg.baseDir = '/Users/kihossei/Library/CloudStorage/GoogleDrive-hosseinikianoosh@gmail.com/My Drive/My Digital Life/Professional/Github_Repos/mfe-jr-dataset/materials/task1/stimuli/mfe_jr'; % !!! UPDATE THIS PATH !!!
cfg.imgSubFolder = 'img';
cfg.neutralFaceFolder = 'neutralC';
cfg.neutralFacePattern = '-N';
% --- Output Directory ---
cfg.outputFolder = '/Users/kihossei/Library/CloudStorage/GoogleDrive-hosseinikianoosh@gmail.com/My Drive/My Digital Life/Professional/Github_Repos/mfe-jr-dataset/materials/task1/stimuli/mfe_jr'; % !!! UPDATE THIS PATH !!!
% --- Experiment Design Parameters ---
cfg.numMainBlocks = 9;
cfg.trialsPerMainBlock = 32;
cfg.numPracticeBlocks = 1;
cfg.trialsPerPracticeBlock = 20;
% --- Stimuli Details ---
cfg.arrowImgRight = fullfile(cfg.imgSubFolder, 'rightArrow.png');
cfg.arrowImgLeft = fullfile(cfg.imgSubFolder, 'leftArrow.png');
cfg.arrowSizeStr = '[.035, .035]';
cfg.locCenterStr = '[0,0]';
cfg.locRightFlankerStr = '[0.0385,0]';
cfg.locLeftFlankerStr = '[-0.0385,0]';
% --- Condition Coding ---
cfg.stimNumRightCong = 5; cfg.stimNumLeftCong = 6;
cfg.stimNumRightIncong = 7; cfg.stimNumLeftIncong = 8;
% --- Output Filename Prefixes ---
cfg.outputPrefixFlanker = 'flanker_block_';
cfg.outputPrefixPractice = 'flanker_practice';
cfg.outputPrefixSurprise = 'surprise_block_';
fprintf('Configuration loaded.\n');

% =========================================================================
%% Initialization & Path Validation
% =========================================================================
fprintf('Initializing workspace and validating paths...\n');
clearvars -except cfg; clc; rng('shuffle');
faceDataLocation = fullfile(cfg.baseDir, cfg.imgSubFolder, cfg.neutralFaceFolder);
if ~isfolder(faceDataLocation); error('Input face data directory not found: %s', faceDataLocation); end
fprintf('Input face data location confirmed: %s\n', faceDataLocation);
if ~isfolder(cfg.outputFolder); fprintf('Output directory not found. Creating: %s\n', cfg.outputFolder); [success, msg, msgID] = mkdir(cfg.outputFolder); if ~success; error('Could not create output directory: %s\nError: %s (%s)', cfg.outputFolder, msg, msgID); end; else; fprintf('Output directory confirmed: %s\n', cfg.outputFolder); end
fprintf('Workspace initialized and paths validated.\n');

% =========================================================================
%% Load and Prepare Face Stimuli List
% =========================================================================
fprintf('Loading neutral face files...\n');
currentDir = pwd; cd(faceDataLocation);
dirContents = dir(['*' cfg.neutralFacePattern '*']);
isFile = ~[dirContents.isdir]; isValidName = ~ismember({dirContents.name}, {'.', '..', '.DS_Store'}); faceFiles = dirContents(isFile & isValidName);
if isempty(faceFiles); cd(currentDir); error('No face files found matching pattern "%s" in %s.', cfg.neutralFacePattern, faceDataLocation); end
allFaceNames = string({faceFiles.name}');
allFacePaths = fullfile(cfg.imgSubFolder, cfg.neutralFaceFolder, allFaceNames);
cd(currentDir);
fprintf('Found %d valid neutral face files.\n', length(allFacePaths));

% =========================================================================
%% Select Faces for Flanker Task (Practice + Main) and Identify Potential Foils
% =========================================================================
fprintf('Selecting faces for trial presentation...\n');
totalTrialsMain = cfg.numMainBlocks * cfg.trialsPerMainBlock;
totalTrialsPractice = cfg.numPracticeBlocks * cfg.trialsPerPracticeBlock;
totalFacesNeededForTrials = totalTrialsMain + totalTrialsPractice;
if totalFacesNeededForTrials > length(allFacePaths); error('Not enough unique faces (%d) for required flanker trials (%d).', length(allFacePaths), totalFacesNeededForTrials); end
numAvailableFaces = length(allFacePaths);
sampledIndices = randsample(numAvailableFaces, totalFacesNeededForTrials);
trialFacePaths = allFacePaths(sampledIndices);
fprintf('Selected %d faces for %d practice and %d main flanker trials.\n', totalFacesNeededForTrials, totalTrialsPractice, totalTrialsMain);
isTrialFace = false(numAvailableFaces, 1); isTrialFace(sampledIndices) = true;
potentialFoilPaths = allFacePaths(~isTrialFace);
fprintf('Identified %d potential foil faces (unused in flanker task).\n', length(potentialFoilPaths));
facesAvailableForBlocks = trialFacePaths;
practiceFacePaths = strings(0,1);
mainTrialFacePaths = strings(0,1);

% =========================================================================
%% Generate Flanker Task Block CSV Files
% =========================================================================
totalBlocks = cfg.numMainBlocks + cfg.numPracticeBlocks;
fprintf('Generating %d flanker block files (practice + main)...\n', totalBlocks);
for blockIdx = 1:totalBlocks
    isPracticeBlock = (blockIdx > cfg.numMainBlocks);
    if isPracticeBlock; blockTypeStr = 'Practice'; trialsThisBlock = cfg.trialsPerPracticeBlock; outputFileName = fullfile(cfg.outputFolder, [cfg.outputPrefixPractice, '.csv']);
    else; blockTypeStr = sprintf('Main Block %d', blockIdx); trialsThisBlock = cfg.trialsPerMainBlock; outputFileName = fullfile(cfg.outputFolder, [cfg.outputPrefixFlanker, num2str(blockIdx), '.csv']); end
    fprintf('  Generating %s (%d trials)...\n', blockTypeStr, trialsThisBlock);
    if trialsThisBlock > length(facesAvailableForBlocks); error('Ran out of unique faces for block %d.', blockIdx); end
    numRemainingFaces = length(facesAvailableForBlocks);
    if trialsThisBlock > numRemainingFaces; error('Ran out of unique faces for block %d. Requested %d, only %d remain.', blockIdx, trialsThisBlock, numRemainingFaces); end
    sampledIndices_block = randsample(numRemainingFaces, trialsThisBlock);
    blockFacePaths = facesAvailableForBlocks(sampledIndices_block);
    facesAvailableForBlocks(sampledIndices_block) = [];
    if isPracticeBlock; practiceFacePaths = [practiceFacePaths; blockFacePaths]; else; mainTrialFacePaths = [mainTrialFacePaths; blockFacePaths]; end
    if mod(trialsThisBlock, 4) ~= 0; warning('Block %d has %d trials, not divisible by 4. Imperfect balancing.', blockIdx, trialsThisBlock); end
    trialsPerCondition = floor(trialsThisBlock / 4); conditions = repelem(1:4, trialsPerCondition)'; remainder = mod(trialsThisBlock, 4);
    if remainder > 0; extraConditions = randperm(4, remainder)'; conditions = [conditions; extraConditions]; end
    conditions = conditions(randperm(trialsThisBlock));
    middleStim = strings(trialsThisBlock, 1); leftStim = strings(trialsThisBlock, 1); rightStim = strings(trialsThisBlock, 1); stimNum = zeros(trialsThisBlock, 1); congruent = zeros(trialsThisBlock, 1); target = strings(trialsThisBlock, 1); locationC = repmat(string(cfg.locCenterStr), trialsThisBlock, 1); locationR = repmat(string(cfg.locRightFlankerStr), trialsThisBlock, 1); locationL = repmat(string(cfg.locLeftFlankerStr), trialsThisBlock, 1); straightFace = blockFacePaths; imageSize = repmat(string(cfg.arrowSizeStr), trialsThisBlock, 1);
    for iTrial = 1:trialsThisBlock
        switch conditions(iTrial)
            case 1; middleStim(iTrial) = cfg.arrowImgRight; leftStim(iTrial) = cfg.arrowImgRight; rightStim(iTrial) = cfg.arrowImgRight; stimNum(iTrial) = cfg.stimNumRightCong; congruent(iTrial) = 1; target(iTrial) = "right";
            case 2; middleStim(iTrial) = cfg.arrowImgRight; leftStim(iTrial) = cfg.arrowImgLeft; rightStim(iTrial) = cfg.arrowImgLeft; stimNum(iTrial) = cfg.stimNumRightIncong; congruent(iTrial) = 0; target(iTrial) = "right";
            case 3; middleStim(iTrial) = cfg.arrowImgLeft; leftStim(iTrial) = cfg.arrowImgLeft; rightStim(iTrial) = cfg.arrowImgLeft; stimNum(iTrial) = cfg.stimNumLeftCong; congruent(iTrial) = 1; target(iTrial) = "left";
            case 4; middleStim(iTrial) = cfg.arrowImgLeft; leftStim(iTrial) = cfg.arrowImgRight; rightStim(iTrial) = cfg.arrowImgRight; stimNum(iTrial) = cfg.stimNumLeftIncong; congruent(iTrial) = 0; target(iTrial) = "left";
        end
    end
    blockTable = table(middleStim, leftStim, rightStim, stimNum, congruent, target, locationC, locationR, locationL, straightFace, imageSize);
    blockTable = blockTable(randperm(height(blockTable)), :);
    writetable(blockTable, outputFileName);
    fprintf('    Saved block data to: %s\n', outputFileName);
end % End flanker block loop

% =========================================================================
%% Select Foil Faces for Memory Task (Based on New Rule)
% =========================================================================
fprintf('Selecting foils for memory task...\n');
oldFacePaths_unique = unique(mainTrialFacePaths); % Unique 'old' faces
numOldFaces = length(oldFacePaths_unique);
numFoilsNeeded = floor(numOldFaces / 2); % Calculate total foils needed
fprintf('  Number of unique old faces (from main blocks): %d\n', numOldFaces);
fprintf('  Required number of new/foil faces (floor(old/2)): %d\n', numFoilsNeeded);
if numFoilsNeeded > length(potentialFoilPaths); warning('Not enough unique unused faces (%d) for required foils (%d). Using all available (%d).', length(potentialFoilPaths), numFoilsNeeded, length(potentialFoilPaths)); numFoilsNeeded = length(potentialFoilPaths); end
if numFoilsNeeded > 0; foilFacePaths = randsample(potentialFoilPaths, numFoilsNeeded); fprintf('  Selected %d foil faces.\n', length(foilFacePaths));
else; foilFacePaths = strings(0,1); fprintf('  Selected 0 foil faces.\n'); end

% =========================================================================
%% Generate Surprise Memory Task CSV Files (Balanced Foils Across 4 Blocks)
% =========================================================================
% This section prepares the 'old' and 'new' (foil) faces, shuffles each list
% separately, then distributes them as evenly as possible into 4 blocks,
% shuffles within each block, and saves them to CSV files.
% =========================================================================
fprintf('Generating surprise memory task files (4 blocks, balancing foils)...\n');

% --- Prepare Old and Foil Tables ---
% Create table for unique old faces (new=0)
if numOldFaces > 0
    oldFacesTable = table(oldFacePaths_unique, zeros(numOldFaces, 1), 'VariableNames', {'surpriseFaces', 'new'});
else
    oldFacesTable = table('Size', [0 2], 'VariableTypes', {'string', 'double'}, 'VariableNames', {'surpriseFaces', 'new'});
end
% Create table for selected foil faces (new=1)
numFoilsSelected = length(foilFacePaths);
if numFoilsSelected > 0
    foilFacesTable = table(foilFacePaths, ones(numFoilsSelected, 1), 'VariableNames', {'surpriseFaces', 'new'});
else
     foilFacesTable = table('Size', [0 2], 'VariableTypes', {'string', 'double'}, 'VariableNames', {'surpriseFaces', 'new'});
end

% --- Error Check: Empty Memory Task? ---
if isempty(oldFacesTable) && isempty(foilFacesTable)
    fprintf('  WARNING: No old or foil faces selected. Cannot generate memory task files. Skipping.\n');
    fprintf('Script finished.\n');
    return;
end

% --- Shuffle Old and Foil Lists Independently ---
fprintf('  Shuffling old and foil face lists separately...\n');
if numOldFaces > 0
    shuffledOldTable = oldFacesTable(randperm(numOldFaces), :);
else
    shuffledOldTable = oldFacesTable; % Keep empty if no old faces
end
if numFoilsSelected > 0
    shuffledFoilTable = foilFacesTable(randperm(numFoilsSelected), :);
else
    shuffledFoilTable = foilFacesTable; % Keep empty if no foils
end

% --- Calculate Distribution for 4 Blocks ---
fprintf('  Calculating distribution of old/foil faces per block...\n');
numBlocks = 4;
% Calculate how many OLD faces per block
baseOldPerBlock = floor(numOldFaces / numBlocks);
remainderOld = mod(numOldFaces, numBlocks);
fprintf('    Old faces per block: Base=%d, Remainder=%d\n', baseOldPerBlock, remainderOld);
% Calculate how many FOIL faces per block
baseFoilsPerBlock = floor(numFoilsSelected / numBlocks);
remainderFoils = mod(numFoilsSelected, numBlocks);
fprintf('    Foil faces per block: Base=%d, Remainder=%d\n', baseFoilsPerBlock, remainderFoils);

% --- Distribute Faces and Create Blocks ---
fprintf('  Creating and shuffling within each block...\n');
currentOldIdx = 0; % Index tracker for shuffled old table
currentFoilIdx = 0; % Index tracker for shuffled foil table

for iBlock = 1:numBlocks
    % Determine number of old faces for this block
    numOldThisBlock = baseOldPerBlock;
    if remainderOld > 0
        numOldThisBlock = numOldThisBlock + 1;
        remainderOld = remainderOld - 1;
    end

    % Determine number of foil faces for this block
    numFoilsThisBlock = baseFoilsPerBlock;
    if remainderFoils > 0
        numFoilsThisBlock = numFoilsThisBlock + 1;
        remainderFoils = remainderFoils - 1;
    end

    % Select the portions for this block from the shuffled lists
    if numOldThisBlock > 0
        oldPortion = shuffledOldTable(currentOldIdx + 1 : currentOldIdx + numOldThisBlock, :);
        currentOldIdx = currentOldIdx + numOldThisBlock; % Update index
    else
        oldPortion = oldFacesTable(1:0,:); % Empty table with correct columns
    end

    if numFoilsThisBlock > 0
        foilPortion = shuffledFoilTable(currentFoilIdx + 1 : currentFoilIdx + numFoilsThisBlock, :);
        currentFoilIdx = currentFoilIdx + numFoilsThisBlock; % Update index
    else
        foilPortion = foilFacesTable(1:0,:); % Empty table with correct columns
    end

    % Combine the old and foil portions for this block
    blockTableCombined = [oldPortion; foilPortion];

    % Shuffle the rows *within* this combined block table
    if height(blockTableCombined) > 0
        blockTableShuffled = blockTableCombined(randperm(height(blockTableCombined)), :);
    else
        blockTableShuffled = blockTableCombined; % Keep empty if block is empty
    end

    % --- Write This Block to a Separate CSV File ---
    outputFileName = fullfile(cfg.outputFolder, [cfg.outputPrefixSurprise, num2str(iBlock), '.csv']);
    writetable(blockTableShuffled, outputFileName);
    fprintf('  Saved %d total trials (%d old, %d foil) to %s (Block %d)\n', ...
            height(blockTableShuffled), numOldThisBlock, numFoilsThisBlock, outputFileName, iBlock);

end % End loop through blocks

% --- Final Confirmation Message ---
fprintf('Script finished successfully.\n');
% =========================================================================
% End of Script
% =========================================================================